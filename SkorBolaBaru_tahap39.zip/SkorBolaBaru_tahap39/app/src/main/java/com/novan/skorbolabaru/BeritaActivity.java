package com.novan.skorbolabaru;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

// Menampilkan isi berita saja (teks), tanpa iklan dan tampilan situs.
// Halaman dimuat di WebView tersembunyi, lalu teks paragraf diambil.
public class BeritaActivity extends Activity {

    static final String JS = "(function(){"
            + "function ambil(root){var ps=root.querySelectorAll('p'),o=[],seen={};"
            + "for(var i=0;i<ps.length;i++){var t=(ps[i].textContent||'').replace(/\\s+/g,' ').trim();"
            + "if(t.length<40||seen[t])continue;"
            + "if(/^(baca juga|baca selengkapnya|advertisement|scroll to continue|simak|lihat juga)/i.test(t))continue;"
            + "seen[t]=1;o.push(t);}return o;}"
            + "var r=document.querySelector('article')||document.querySelector('[itemprop=articleBody]')||document.querySelector('main')||document.body;"
            + "var o=ambil(r);if(o.length<3)o=ambil(document.body);"
            + "var h=document.querySelector('h1');"
            + "return JSON.stringify({judul:h?h.textContent.trim():document.title,isi:o.join('\\n\\n')});})()";

    final Handler h = new Handler(Looper.getMainLooper());
    WebView web;
    TextView status, isi;
    ScrollView gulung;
    Button btnAsli;
    boolean selesai = false, gagalTampil = false, tampilAsli = false;
    int percobaan = 0;
    String linkAwal;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        } catch (Exception e) {
            // abaikan
        }
        linkAwal = getIntent().getStringExtra("link");
        setTitle("");
        if (getActionBar() != null) getActionBar().hide();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        status = new TextView(this);
        status.setPadding(24, 16, 24, 8);
        status.setTextSize(16);
        status.setText("Memuat isi berita...");
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        gulung = new ScrollView(this);
        LinearLayout kolom = new LinearLayout(this);
        kolom.setOrientation(LinearLayout.VERTICAL);
        kolom.setPadding(24, 8, 24, 24);
        isi = new TextView(this);
        isi.setTextSize(18);
        isi.setLineSpacing(0, 1.2f);
        isi.setTextIsSelectable(true);
        isi.setFocusable(true);
        kolom.addView(isi);
        gulung.addView(kolom);
        root.addView(gulung, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                if (selesai || url == null) return;
                if (url.contains("news.google.com") || url.contains("consent.google") || url.startsWith("about:")) return;
                h.postDelayed(() -> ambilTeks(), 1200);
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

        btnAsli = new Button(this);
        btnAsli.setText("Halaman asli");
        btnAsli.setOnClickListener(v -> alihTampilan());
        root.addView(btnAsli, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        if (linkAwal != null) {
            web.loadUrl(linkAwal);
            h.postDelayed(() -> { if (!selesai) gagal(); }, 25000);
        } else {
            gagal();
        }
    }

    void alihTampilan() {
        tampilAsli = !tampilAsli;
        if (tampilAsli) {
            gulung.setVisibility(View.GONE);
            web.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            btnAsli.setText("Kembali ke isi berita");
        } else {
            gulung.setVisibility(View.VISIBLE);
            web.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
            btnAsli.setText("Halaman asli");
        }
    }

    void ambilTeks() {
        if (selesai || isFinishing()) return;
        web.evaluateJavascript(JS, val -> {
            if (selesai || val == null) return;
            try {
                String teks = new JSONArray("[" + val + "]").getString(0);
                JSONObject o = new JSONObject(teks);
                String isiTeks = o.optString("isi");
                if (isiTeks.length() > 200) {
                    selesai = true;
                    isi.setText(isiTeks);
                    status.setVisibility(View.GONE);
                    // Fokus pembaca layar langsung ke isi berita, jadi langsung dibacakan.
                    isi.post(() -> isi.performAccessibilityAction(
                            android.view.accessibility.AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null));
                    return;
                }
            } catch (Exception e) {
                // coba lagi di bawah
            }
            if (++percobaan < 4) h.postDelayed(() -> ambilTeks(), 2000);
            else gagal();
        });
    }

    void gagal() {
        if (selesai || gagalTampil) return;
        gagalTampil = true;
        status.setText("Isi berita tidak bisa diambil. Ketuk Halaman asli untuk melihatnya.");
    }

    @Override
    public void onBackPressed() {
        if (tampilAsli) alihTampilan();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (web != null) {
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
