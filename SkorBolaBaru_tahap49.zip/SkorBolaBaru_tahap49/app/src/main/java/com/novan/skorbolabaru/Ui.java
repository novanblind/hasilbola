package com.novan.skorbolabaru;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Layar daftar yang ramah pembaca layar: kontras tinggi (hitam, putih, kuning), teks besar
 * (satuan sp), judul bertanda heading, dan pesan status yang diumumkan otomatis.
 */
public class Ui {
    public static final int BG = 0xFF000000, FG = 0xFFFFFFFF, BTN = 0xFFFFD600, SOFT = 0xFFB3E5FC;

    public final Activity act;
    public final TextView heading, status;
    public final ListView list;

    public Ui(Activity a, String title, String bottomLabel, final Runnable bottomAction) {
        act = a;
        a.setTitle(title);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        int p = dp(a, 16);
        root.setPadding(p, p, p, p);

        heading = text(a, title, 26, FG);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        if (Build.VERSION.SDK_INT >= 28) heading.setAccessibilityHeading(true);
        root.addView(heading);

        status = text(a, "", 18, SOFT);
        status.setVisibility(View.GONE);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        root.addView(status);

        list = new ListView(a);
        list.setBackgroundColor(BG);
        list.setDivider(new android.graphics.drawable.ColorDrawable(0xFF444444));
        list.setDividerHeight(dp(a, 1));
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button b = button(a, bottomLabel);
        b.setOnClickListener(v -> bottomAction.run());
        root.addView(b);
        a.setContentView(root);
    }

    public void setTitle(String t) {
        act.setTitle(t);
        heading.setText(t);
    }

    /** Pesan status: tampil di layar (diumumkan pembaca layar) dan sebagai Toast. */
    public void say(String msg) {
        status.setText(msg);
        status.setVisibility(msg == null || msg.isEmpty() ? View.GONE : View.VISIBLE);
        if (msg != null && !msg.isEmpty()) Toast.makeText(act, msg, Toast.LENGTH_SHORT).show();
    }

    public void setItems(List<String> items, AdapterView.OnItemClickListener l) {
        list.setAdapter(new ArrayAdapter<String>(act, 0, items) {
            @Override
            public View getView(int position, View convert, ViewGroup parent) {
                TextView t = convert instanceof TextView ? (TextView) convert : text(act, "", 20, FG);
                t.setText(getItem(position));
                t.setMinHeight(dp(act, 56));
                t.setPadding(dp(act, 8), dp(act, 12), dp(act, 8), dp(act, 12));
                return t;
            }
        });
        list.setOnItemClickListener(l);
    }

    public static int dp(Activity a, int v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static TextView text(Activity a, String t, int sp, int color) {
        TextView v = new TextView(a);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setPadding(0, dp(a, 8), 0, dp(a, 4));
        return v;
    }

    public static Button button(Activity a, String label) {
        Button b = new Button(a);
        b.setText(label);
        b.setTextSize(20);
        b.setAllCaps(false);
        b.setTextColor(0xFF000000);
        b.setMinHeight(dp(a, 56));
        GradientDrawable g = new GradientDrawable();
        g.setColor(BTN);
        g.setCornerRadius(dp(a, 8));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(a, 8);
        b.setLayoutParams(lp);
        return b;
    }
}
