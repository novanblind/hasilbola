package com.novan.skorbolabaru;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Pengambil halaman web: ulangi saat gagal, ikuti pengalihan (termasuk http ke https). */
public final class Http {
    public interface Retry { void onRetry(int attempt); }

    private static final String UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
    private static final int MAX_BYTES = 4 * 1024 * 1024;

    /** Mengembalikan isi halaman, atau null bila semua percobaan gagal. Dipanggil di thread latar. */
    public static String get(String url, int maxTry, int timeoutMs, Retry retry) {
        for (int attempt = 1; attempt <= maxTry; attempt++) {
            try {
                String body = once(url, timeoutMs);
                if (body != null && !body.isEmpty()) return body;
            } catch (Exception ignored) {
            }
            if (attempt < maxTry) {
                if (retry != null) retry.onRetry(attempt + 1);
                try {
                    Thread.sleep(600L * attempt);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return null;
                }
            }
        }
        return null;
    }

    private static String once(String start, int timeoutMs) throws Exception {
        String url = start;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            try {
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(timeoutMs);
                c.setReadTimeout(timeoutMs);
                c.setRequestProperty("User-Agent", UA);
                c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                c.setRequestProperty("Accept-Language", "id-ID,id;q=0.9,en;q=0.7");
                int code = c.getResponseCode();
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null || loc.isEmpty()) return null;
                    url = new URL(new URL(url), loc).toString();
                    continue;
                }
                if (code != 200) return null;
                String charset = "UTF-8";
                String ct = c.getContentType();
                if (ct != null) {
                    int i = ct.toLowerCase().indexOf("charset=");
                    if (i >= 0) {
                        charset = ct.substring(i + 8).trim().replace("\"", "");
                        int semi = charset.indexOf(';');
                        if (semi >= 0) charset = charset.substring(0, semi).trim();
                    }
                }
                InputStream in = c.getInputStream();
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    bos.write(buf, 0, n);
                    if (bos.size() > MAX_BYTES) break;
                }
                in.close();
                try {
                    return new String(bos.toByteArray(), charset);
                } catch (Exception e) {
                    return new String(bos.toByteArray(), "UTF-8");
                }
            } finally {
                c.disconnect();
            }
        }
        return null;
    }

    private Http() { }
}
