package com.novan.skorbolabaru;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pengurai daftar berita dan inti naskah berita. Port dari logika plugin Jieshuo (main.lua). */
public final class NewsParser {
    public static final int MAX_NEWS = 50;

    private static final int CI = Pattern.CASE_INSENSITIVE;
    private static final int DOT = Pattern.DOTALL;

    private static final Pattern CDATA = Pattern.compile("<!\\[CDATA\\[(.*?)\\]\\]>", DOT);
    private static final Pattern TAG = Pattern.compile("<[^>]*>");
    private static final Pattern NUM = Pattern.compile("&#(\\d+);");
    private static final Pattern HEX = Pattern.compile("&#[xX]([0-9a-fA-F]+);");
    private static final Pattern NEWLINES = Pattern.compile("[\\r\\n]+");
    private static final Pattern ITEM_PRESENT = Pattern.compile("<item", CI);
    private static final Pattern ITEM = Pattern.compile("<item[^>]*>(.*?)</item>", CI | DOT);
    private static final Pattern T_TITLE = tagPattern("title");
    private static final Pattern T_LINK = tagPattern("link");
    private static final Pattern T_DESC = tagPattern("description");
    private static final Pattern T_DATE = tagPattern("pubDate");

    private static final Pattern DETIK_A = Pattern.compile(
            "<a[^>]*?href=\"(https?://[a-z0-9.\\-]*?detik\\.com/[^\"]*?/d-\\d+/[^\"]*?)\"[^>]*?>(.*?)</a>", DOT);
    private static final Pattern KOMPAS_A = Pattern.compile(
            "<a[^>]*?href=\"(https?://[a-z0-9.\\-]*?kompas\\.com/read/\\d+/[^\"]*?)\"[^>]*?>(.*?)</a>", DOT);

    private static final Pattern PARA = Pattern.compile("<p(?=[\\s>])[^>]*>(.*?)</p>", CI | DOT);

    private static final Pattern PFX_DETIK = Pattern.compile("^[\\w\\s.,]+\\s*-\\s*detik[a-z]+\\s*", CI);
    private static final Pattern PFX_KOMPAS = Pattern.compile("^[\\w\\s.,]*kompas\\.com\\s*-\\s*", CI);
    private static final Pattern PFX_CNN1 = Pattern.compile("^[\\w\\s.,]*cnn\\s+indonesia\\s*--\\s*", CI);
    private static final Pattern PFX_CNN2 = Pattern.compile("^[\\w\\s.,]*cnn\\s+indonesia\\s*-\\s*", CI);
    private static final Pattern PFX_JKT = Pattern.compile("^jakarta\\s*-\\s*", CI);

    private static final Pattern JUNK_FUNC = Pattern.compile("function\\s*\\(");
    private static final Pattern JUNK_VAR = Pattern.compile("var\\s+");
    private static final Pattern HASH_NUM = Pattern.compile("^#\\d+");

    private static final String[] TERMINAL = {
        "ide belanja", "pilihan produk terbaik", "anda menyukai artikel ini",
        "dapatkan informasi dan insight", "bayangkan seorang anak indonesia",
        "mari hadirkan akses literasi", "jagatliterasi", "simak video", "rekomendasi produk",
        "artikel terkait", "berita terkait", "berita populer", "pilihan redaksi", "baca artikel",
        "daftar detikers", "copyright"
    };

    private static final String[] JUNK_START = {
        "baca juga", "pilihan redaksi", "simak video", "dapatkan update", "(sumber", "iklan",
        "advertisement", "lihat juga", "tonton juga", "gambas", "tag:", "komentar", "copyright"
    };

    private static final String[] JUNK_CONTAINS = {
        "scroll to continue", "lanjutkan membaca", "daftar detikers", "userlogin",
        "this.open", "@mouseenter"
    };

    private static final String[] CONTAINERS = {
        "detail__body-text", "itp_bodycontent", "read__content", "article__content",
        "detail-text", "detail_text"
    };

    private static final String[] END_MARKERS = {
        "class=\"detail__tag", "class='detail__tag", "class=\"read__tag", "class='read__tag",
        "class=\"detail__comment", "id=\"comment", "<footer"
    };

    private static Pattern tagPattern(String name) {
        return Pattern.compile("<" + name + "[^>]*>(.*?)</" + name + ">", CI | DOT);
    }

    private static String getTag(String block, Pattern p) {
        Matcher m = p.matcher(block);
        return m.find() ? m.group(1) : null;
    }

    // ------------------------------------------------------------ utilitas teks

    static String decodeEntities(String txt) {
        if (txt == null) return "";
        txt = replaceCodepoints(txt, NUM, 10);
        txt = replaceCodepoints(txt, HEX, 16);
        txt = txt.replace("&nbsp;", " ").replace("&quot;", "\"").replace("&apos;", "'")
                .replace("&ldquo;", "\"").replace("&rdquo;", "\"")
                .replace("&lsquo;", "'").replace("&rsquo;", "'")
                .replace("&hellip;", "...").replace("&mdash;", "\u2014").replace("&ndash;", "\u2013")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&");
        return txt;
    }

    private static String replaceCodepoints(String s, Pattern p, int radix) {
        Matcher m = p.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String rep = "";
            try {
                int cp = Integer.parseInt(m.group(1), radix);
                if (Character.isValidCodePoint(cp)) rep = new String(Character.toChars(cp));
            } catch (Exception ignored) {
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    static String cleanTag(String txt) {
        if (txt == null) return "";
        txt = CDATA.matcher(txt).replaceAll("$1");
        txt = TAG.matcher(txt).replaceAll("");
        txt = decodeEntities(txt);
        txt = NEWLINES.matcher(txt).replaceAll(" ");
        return txt.trim();
    }

    /** Membuang awalan nama wartawan, nama portal, atau kota di awal paragraf. */
    public static String cleanPrefix(String txt) {
        if (txt == null) return "";
        txt = PFX_DETIK.matcher(txt).replaceFirst("");
        txt = PFX_KOMPAS.matcher(txt).replaceFirst("");
        txt = PFX_CNN1.matcher(txt).replaceFirst("");
        txt = PFX_CNN2.matcher(txt).replaceFirst("");
        txt = PFX_JKT.matcher(txt).replaceFirst("");
        return txt.trim();
    }

    /** Awal bagian penutup, iklan, atau rekomendasi: pembacaan naskah berhenti di sini. */
    static boolean isTerminalJunk(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        for (String s : TERMINAL) if (lower.contains(s)) return true;
        return HASH_NUM.matcher(lower).find();
    }

    static boolean isJunkLine(String text) {
        if (text.length() <= 20) return true;
        String lower = text.toLowerCase(Locale.ROOT);
        for (String s : JUNK_START) if (lower.startsWith(s)) return true;
        for (String s : JUNK_CONTAINS) if (lower.contains(s)) return true;
        return JUNK_FUNC.matcher(lower).find() || JUNK_VAR.matcher(lower).find();
    }

    // ------------------------------------------------------------ daftar berita

    public static List<NewsItem> parseNews(String body, String srcName) {
        List<NewsItem> list = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (body == null || body.isEmpty()) return list;

        // 1. RSS XML
        if (ITEM_PRESENT.matcher(body).find()) {
            Matcher m = ITEM.matcher(body);
            while (m.find()) {
                String it = m.group(1);
                String title = cleanTag(getTag(it, T_TITLE));
                String link = cleanTag(getTag(it, T_LINK));
                String desc = cleanTag(getTag(it, T_DESC));
                String date = cleanTag(getTag(it, T_DATE));
                if (!title.isEmpty() && !link.isEmpty() && seen.add(link)) {
                    link = link.replaceFirst("^http://", "https://");
                    list.add(new NewsItem(title, link, desc, date, srcName == null ? "" : srcName));
                    if (list.size() >= MAX_NEWS) break;
                }
            }
            if (!list.isEmpty()) return list;
        }

        // 2. Scraping halaman web
        boolean detik = "Detik".equals(srcName);
        boolean kompas = "Kompas".equals(srcName);
        if (!detik && !kompas) {
            detik = body.contains("detik.com");
            kompas = !detik && body.contains("kompas.com");
        }
        if (detik) scrape(DETIK_A, body, "Detik", list, seen);
        else if (kompas) scrape(KOMPAS_A, body, "Kompas", list, seen);
        return list;
    }

    private static void scrape(Pattern p, String body, String src, List<NewsItem> list, Set<String> seen) {
        Matcher m = p.matcher(body);
        while (m.find()) {
            String title = cleanTag(m.group(2));
            String link = m.group(1).replaceFirst("\\?.*$", "").replaceFirst("^http://", "https://");
            if (title.length() > 15 && !seen.contains(link) && !isJunkLine(title)) {
                seen.add(link);
                list.add(new NewsItem(title, link, title, "", src));
                if (list.size() >= MAX_NEWS) break;
            }
        }
    }

    // ------------------------------------------------------------ isi naskah

    /** Mengambil murni inti naskah berita, paragraf dipisah baris kosong. Kosong bila gagal. */
    public static String extractFullArticle(String html) {
        if (html == null || html.isEmpty()) return "";

        // 1. Wadah artikel utama
        int startPos = -1;
        for (String marker : CONTAINERS) {
            Matcher m = Pattern.compile(Pattern.quote(marker), CI).matcher(html);
            if (m.find()) {
                int tagStart = html.lastIndexOf('<', m.start());
                if (tagStart >= 0) {
                    startPos = tagStart;
                    break;
                }
            }
        }
        String block = startPos >= 0 ? html.substring(startPos) : html;

        // 2. Batasi titik akhir bila ada penanda footer atau komentar
        if (startPos >= 0) {
            String lowerBlock = block.toLowerCase(Locale.ROOT);
            if (lowerBlock.length() == block.length()) {
                int endPos = block.length();
                for (String em : END_MARKERS) {
                    int i = lowerBlock.indexOf(em);
                    if (i >= 0 && i + 1 > 50 && i + 1 < endPos) endPos = i + 1;
                }
                block = block.substring(0, endPos);
            }
        }

        // 3. Paragraf berita
        List<String> paras = collectParagraphs(block, 20);

        // Cadangan darurat: seluruh halaman
        if (paras.isEmpty() && startPos >= 0) paras = collectParagraphs(html, 25);

        if (paras.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < paras.size(); i++) {
            if (i > 0) sb.append("\n\n");
            sb.append(paras.get(i));
        }
        return sb.toString();
    }

    private static List<String> collectParagraphs(String block, int minLen) {
        List<String> paras = new ArrayList<>();
        Matcher m = PARA.matcher(block);
        while (m.find()) {
            String p = TAG.matcher(m.group(1)).replaceAll("");
            p = decodeEntities(p);
            p = NEWLINES.matcher(p).replaceAll(" ").trim();

            // Berhenti di widget rekomendasi belanja atau berita populer
            if (isTerminalJunk(p)) break;

            if (paras.isEmpty()) p = cleanPrefix(p);

            if (p.length() > minLen && !isJunkLine(p)) paras.add(p);
        }
        return paras;
    }

    private NewsParser() { }
}
