package com.novan.skorbolabaru;

import java.io.Serializable;

public class NewsItem implements Serializable {
    public final String title, link, desc, date, src;

    public NewsItem(String title, String link, String desc, String date, String src) {
        this.title = title;
        this.link = link;
        this.desc = desc;
        this.date = date;
        this.src = src;
    }
}
