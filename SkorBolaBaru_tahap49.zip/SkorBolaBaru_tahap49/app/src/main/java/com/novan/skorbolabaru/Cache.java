package com.novan.skorbolabaru;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Cache di memori: daftar berita 5 menit, isi berita selama aplikasi hidup. */
public final class Cache {
    public static final long LIST_MS = 5 * 60 * 1000L;

    public static final class Entry {
        public final long time = System.currentTimeMillis();
        public final List<NewsItem> list;
        Entry(List<NewsItem> l) { list = l; }
    }

    private static final Map<String, Entry> LISTS = new HashMap<>();
    private static final Map<String, String> ARTICLES = new HashMap<>();

    public static synchronized Entry list(String key) { return LISTS.get(key); }
    public static synchronized void putList(String key, List<NewsItem> l) { LISTS.put(key, new Entry(l)); }
    public static synchronized String article(String link) { return ARTICLES.get(link); }
    public static synchronized void putArticle(String link, String text) { ARTICLES.put(link, text); }

    private Cache() { }
}
