package com.novan.skorbolabaru;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Layar 4: inti naskah berita. Tanpa judul layar, agar pembaca layar langsung membacakan
 * naskah dari kata pertama. Tombol: Salin Berita dan Kembali.
 */
public class ArticleActivity extends Activity {
    private static final int MAX_TRY = 3;
    private static final int TIMEOUT_MS = 8000;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private volatile boolean alive = true;
    private NewsItem item;
    private TextView status, body;
    private Button copy, back;
    private String fullText = "";

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        item = (NewsItem) getIntent().getSerializableExtra("item");
        if (item == null) { finish(); return; }
        setTitle(" ");

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 16);
        box.setPadding(pad, pad, pad, pad);
        sv.addView(box, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = Ui.text(this, "Mengambil isi berita lengkap...", 18, Ui.SOFT);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        box.addView(status);

        body = Ui.text(this, "", 20, Ui.FG);
        body.setLineSpacing(0f, 1.25f);
        body.setFocusable(true);
        body.setVisibility(View.GONE);
        box.addView(body);

        copy = Ui.button(this, "Salin Berita");
        copy.setVisibility(View.GONE);
        copy.setOnClickListener(v -> copyContent());
        box.addView(copy);

        back = Ui.button(this, "Kembali");
        back.setOnClickListener(v -> finish());
        box.addView(back);

        setContentView(sv);
        load();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        alive = false;
        pool.shutdownNow();
    }

    private void say(final String msg) {
        main.post(() -> { if (alive) status.setText(msg); });
    }

    private boolean enough(String t) {
        return t != null && t.length() > item.title.length() + 30;
    }

    private void load() {
        String cached = Cache.article(item.link);
        if (enough(cached)) { present(cached); return; }
        pool.execute(() -> {
            String fetchUrl = item.link;
            if (item.link.contains("kompas.com") && !item.link.contains("page=all")) {
                fetchUrl = item.link + (item.link.contains("?") ? "&page=all" : "?page=all");
            }
            String text = fetchAndExtract(fetchUrl, MAX_TRY, true);
            if (!enough(text) && !fetchUrl.equals(item.link)) text = fetchAndExtract(item.link, 2, false);
            if (!enough(text)) {
                text = item.desc != null && item.desc.length() > item.title.length()
                        ? NewsParser.cleanPrefix(item.desc) : item.title;
            } else {
                Cache.putArticle(item.link, text);
            }
            final String result = text;
            main.post(() -> { if (alive) present(result); });
        });
    }

    private String fetchAndExtract(String url, int tries, boolean announce) {
        String html = Http.get(url, tries, TIMEOUT_MS, n -> {
            if (announce) say("Koneksi lambat, mencoba lagi " + n + " dari " + MAX_TRY + "...");
        });
        return html == null ? "" : NewsParser.extractFullArticle(html);
    }

    private void present(String text) {
        fullText = text == null || text.isEmpty() ? "(Konten lengkap tidak tersedia)." : text;
        status.setVisibility(View.GONE);
        body.setText(fullText);
        body.setVisibility(View.VISIBLE);
        copy.setVisibility(View.VISIBLE);
        // Pindahkan fokus pembaca layar ke naskah supaya langsung dibacakan dari kata pertama.
        body.post(() -> {
            try {
                body.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null);
            } catch (Exception ignored) {
            }
        });
    }

    private void copyContent() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Berita", fullText));
            Toast.makeText(this, "Inti berita berhasil disalin!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal menyalin berita.", Toast.LENGTH_SHORT).show();
        }
    }
}
