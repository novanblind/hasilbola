package com.novan.skorbolabaru;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

// Menampilkan isi berita saja (teks), tanpa iklan dan tampilan situs.
// Halaman dimuat di WebView tersembunyi, lalu teks paragraf diambil.
public class BeritaActivity extends Activity {

    static final String JS = "(function(){"
            + "var BP=/(syarat\\s*&\\s*ketentuan|kebijakan privasi|cookie|berusia 18|pengguna dewasa|cakap secara hukum|hak cipta|all rights reserved|berlangganan|aktifkan notifikasi|izinkan notifikasi|terms of service|privacy policy|enable javascript)/i;"
            + "function ambil(root){var ps=root.querySelectorAll('p'),o=[],seen={};"
            + "for(var i=0;i<ps.length;i++){var t=(ps[i].textContent||'').replace(/\\s+/g,' ').trim();"
            + "if(t.length<25||seen[t])continue;"
            + "if(/^(baca juga|baca selengkapnya|advertisement|scroll to continue|simak|lihat juga)/i.test(t)||BP.test(t))continue;"
            + "seen[t]=1;o.push(t);}return o;}"
            + "var r=document.querySelector('article')||document.querySelector('[itemprop=articleBody]')||document.querySelector('main')||document.body;"
            + "var o=ambil(r);if(o.length<3)o=ambil(document.body);"
            + "if(o.join('').length<200){var L=(document.body.innerText||'').split(/\\n+/);o=[];var sn={};"
            + "for(var j=0;j<L.length;j++){var l=L[j].replace(/\\s+/g,' ').trim();if(l.length<60||sn[l]||BP.test(l))continue;sn[l]=1;o.push(l);}}"
            + "var h=document.querySelector('h1');"
            + "return JSON.stringify({judul:h?h.textContent.trim():document.title,isi:o.join('\\n\\n')});})()";

    final Handler h = new Handler(Looper.getMainLooper());
    WebView web;
    TextView status, isi;
    ScrollView gulung;
    Button btnAsli;
    boolean selesai = false, gagalTampil = false, tampilAsli = false;
    int percobaan = 0;
    String linkAwal;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        } catch (Exception e) {
            // abaikan
        }
        linkAwal = getIntent().getStringExtra("link");
        setTitle("");
        if (getActionBar() != null) getActionBar().hide();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        status = new TextView(this);
        status.setPadding(24, 16, 24, 8);
        status.setTextSize(16);
        status.setText("Memuat isi berita...");
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        gulung = new ScrollView(this);
        LinearLayout kolom = new LinearLayout(this);
        kolom.setOrientation(LinearLayout.VERTICAL);
        kolom.setPadding(24, 8, 24, 24);
        isi = new TextView(this);
        isi.setTextSize(18);
        isi.setLineSpacing(0, 1.2f);
        isi.setTextIsSelectable(true);
        isi.setFocusable(true);
        kolom.addView(isi);
        gulung.addView(kolom);
        root.addView(gulung, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        // Hanya teks yang dibutuhkan: gambar, video, dan iklan tidak perlu diunduh supaya isi berita cepat muncul.
        s.setLoadsImagesAutomatically(false);
        s.setBlockNetworkImage(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUseWideViewPort(true);
        web.setWebChromeClient(new android.webkit.WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                progres = p;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v, android.webkit.WebResourceRequest r) {
                if (dilarang(r.getUrl().toString(), r.isForMainFrame())) {
                    return new android.webkit.WebResourceResponse("text/plain", "UTF-8",
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (selesai || url == null) return;
                if (url.contains("news.google.com") || url.contains("consent.google") || url.startsWith("about:")) {
                    // Halaman perantara Google: kalau tidak meneruskan sendiri, cari tautan ke situs berita aslinya.
                    h.postDelayed(() -> ikutiTautan(), 1500);
                    return;
                }
                h.postDelayed(() -> ambilTeks(), 200);
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

        btnAsli = new Button(this);
        btnAsli.setText("Halaman asli");
        btnAsli.setOnClickListener(v -> alihTampilan());
        root.addView(btnAsli, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        if (linkAwal != null) {
            // Tautan Google News lama memuat alamat situs aslinya di dalamnya: buka langsung, lewati halaman perantara.
            muatLink();
            jadwalAmbil();
            h.postDelayed(() -> { if (!selesai) gagal(); }, 25000);
        } else {
            gagal();
        }
    }

    boolean sudahIkuti = false;
    volatile int progres = 0;
    int panjangLama = -1;

    static final String[] BLOK_HOST = {"doubleclick", "googlesyndication", "googleadservices", "adservice", "adsystem",
            "google-analytics", "googletagmanager", "googletagservices", "facebook.net", "facebook.com/tr", "taboola",
            "outbrain", "criteo", "adnxs", "scorecardresearch", "chartbeat", "hotjar", "amazon-adsystem", "popads",
            "onesignal", "pubmatic", "rubiconproject", "moatads", "quantserve", "clarity.ms", "mgid", "teads"};
    static final String[] BLOK_EKS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".ico", ".mp4", ".webm", ".m3u8",
            ".mp3", ".woff", ".woff2", ".ttf", ".otf"};

    static boolean dilarang(String u, boolean utama) {
        if (utama) return false;
        String k = u.toLowerCase(java.util.Locale.ROOT);
        for (String b : BLOK_HOST) if (k.contains(b)) return true;
        String jalur = k;
        int q = jalur.indexOf('?');
        if (q >= 0) jalur = jalur.substring(0, q);
        for (String e : BLOK_EKS) if (jalur.endsWith(e)) return true;
        return false;
    }

    // Alamat situs asli yang tersimpan di tautan Google News format lama (base64); null kalau formatnya baru.
    static String urlDariGoogle(String link) {
        try {
            int i = link.indexOf("/articles/");
            if (i < 0) return null;
            String id = link.substring(i + 10);
            int q = id.indexOf('?');
            if (q >= 0) id = id.substring(0, q);
            byte[] b = android.util.Base64.decode(id,
                    android.util.Base64.URL_SAFE | android.util.Base64.NO_PADDING | android.util.Base64.NO_WRAP);
            String t = new String(b, "ISO-8859-1");
            int k = t.indexOf("http");
            if (k < 0) return null;
            int e = k;
            while (e < t.length() && t.charAt(e) >= 33 && t.charAt(e) < 127) e++;
            String u = t.substring(k, e);
            return u.length() < 12 ? null : u;
        } catch (Exception e) {
            return null;
        }
    }

    String alasan = "";

    // Alamat situs asli dicari, teksnya diunduh langsung (tanpa iklan dan tanpa WebView) lalu diambil isi beritanya.
    // Kalau cara itu tidak menghasilkan teks, WebView tersembunyi dipakai sebagai cadangan.
    void muatLink() {
        final String langsung = urlDariGoogle(linkAwal);
        new Thread(() -> {
            String u = langsung;
            if (u == null) u = linkAwal.contains("news.google.com") ? bukaGoogleNews(linkAwal) : linkAwal;
            String teks = "";
            if (u != null) {
                try {
                    // Pengurai khusus CNN Indonesia, detik, dan Kompas lebih dulu; pengurai umum sebagai cadangan.
                    String alamat = u;
                    if (u.contains("kompas.com") && !u.contains("page=all")) alamat = u + (u.contains("?") ? "&" : "?") + "page=all";
                    String html = Http.get(alamat, 3, 8000, null);
                    if (html == null && !alamat.equals(u)) html = Http.get(u, 2, 8000, null);
                    if (html != null) {
                        String t1 = NewsParser.extractFullArticle(html);
                        if (t1.length() >= 120) teks = t1;
                        else {
                            String t2 = ekstrakTeks(html);
                            if (t2.length() > 400) teks = t2;
                        }
                    }
                } catch (Exception e) {
                    teks = "";
                }
            }
            final String fu = u, ft = teks;
            h.post(() -> {
                if (isFinishing() || selesai) return;
                if (!ft.isEmpty()) {
                    tampilkan(ft);
                    return;
                }
                alasan = fu == null ? "alamat situs asli tidak bisa didapat dari Google"
                        : "situs tidak memberi isi berita lewat unduhan langsung";
                web.loadUrl(fu != null ? fu : linkAwal);
            });
        }).start();
    }

    static final java.util.regex.Pattern POLA_BP = java.util.regex.Pattern.compile(
            "(syarat\\s*&\\s*ketentuan|kebijakan privasi|cookie|berusia 18|pengguna dewasa|cakap secara hukum|hak cipta|all rights reserved|berlangganan|aktifkan notifikasi|izinkan notifikasi|terms of service|privacy policy|enable javascript)",
            java.util.regex.Pattern.CASE_INSENSITIVE);

    static String ekstrakTeks(String html) {
        if (html == null || html.length() < 500) return "";
        int f = java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.DOTALL;
        String t = html;
        t = java.util.regex.Pattern.compile("<(script|style|noscript|svg|iframe)\\b.*?</\\1>", f).matcher(t).replaceAll(" ");
        t = java.util.regex.Pattern.compile("<!--.*?-->", f).matcher(t).replaceAll(" ");
        t = java.util.regex.Pattern.compile("<(nav|header|footer|aside|form)\\b.*?</\\1>", f).matcher(t).replaceAll(" ");
        java.util.regex.Matcher ma = java.util.regex.Pattern.compile("<article\\b.*?</article>", f).matcher(t);
        StringBuilder art = new StringBuilder();
        while (ma.find()) art.append(ma.group()).append("\n");
        if (art.length() > 600) t = art.toString();
        t = java.util.regex.Pattern.compile("<br\\s*/?>|</(p|div|li|h[1-6]|tr|section)>", f).matcher(t).replaceAll("\n");
        t = java.util.regex.Pattern.compile("<[^>]+>", f).matcher(t).replaceAll(" ");
        t = t.replace("&nbsp;", " ").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&ldquo;", "\u201c").replace("&rdquo;", "\u201d")
                .replace("&#8220;", "\u201c").replace("&#8221;", "\u201d").replace("&#8217;", "'").replace("&amp;", "&");
        StringBuilder out = new StringBuilder();
        java.util.HashSet<String> ada = new java.util.HashSet<>();
        for (String baris : t.split("\n")) {
            String l = baris.replaceAll("\\s+", " ").trim();
            if (l.length() < 50 || !ada.add(l) || POLA_BP.matcher(l).find()) continue;
            String k = l.toLowerCase(java.util.Locale.ROOT);
            if (k.startsWith("baca juga") || k.startsWith("baca selengkapnya") || k.startsWith("advertisement")
                    || k.startsWith("scroll to continue") || k.startsWith("simak") || k.startsWith("lihat juga")) continue;
            char c = l.charAt(l.length() - 1);
            boolean akhir = ".!?\"\u201d:)'".indexOf(c) >= 0;
            if (!akhir && l.length() < 120) continue;
            if (out.length() > 0) out.append("\n\n");
            out.append(l);
        }
        return out.toString();
    }

    void tampilkan(String isiTeks) {
        selesai = true;
        isi.setText(isiTeks);
        status.setVisibility(View.GONE);
        // Fokus pembaca layar langsung ke isi berita, jadi langsung dibacakan.
        isi.post(() -> isi.performAccessibilityAction(
                android.view.accessibility.AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null));
    }

    static String ambilHttp(String alamat, String badan) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(alamat).openConnection();
        try {
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36");
            c.setRequestProperty("Cookie", "CONSENT=YES+cb");
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            if (badan != null) {
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
                c.getOutputStream().write(badan.getBytes("UTF-8"));
            }
            if (c.getResponseCode() != 200) return "";
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            br.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    static String bukaGoogleNews(String link) {
        try {
            int i = link.indexOf("/articles/");
            if (i < 0) return null;
            String id = link.substring(i + 10);
            int q = id.indexOf('?');
            if (q >= 0) id = id.substring(0, q);
            String sg = "", ts = "";
            for (String dasar : new String[]{"https://news.google.com/articles/", "https://news.google.com/rss/articles/"}) {
                String html = ambilHttp(dasar + id, null);
                java.util.regex.Matcher a = java.util.regex.Pattern.compile("data-n-a-sg=\"([^\"]+)\"").matcher(html);
                java.util.regex.Matcher b = java.util.regex.Pattern.compile("data-n-a-ts=\"([^\"]+)\"").matcher(html);
                if (a.find() && b.find()) {
                    sg = a.group(1);
                    ts = b.group(1);
                    break;
                }
            }
            if (sg.isEmpty() || ts.isEmpty()) return null;
            String dalam = "[\"garturlreq\",[[\"X\",\"X\",[\"X\",\"X\"],null,null,1,1,\"US:en\",null,1,null,null,null,null,null,0,1],"
                    + "\"X\",\"X\",1,[1,1,1],1,1,null,0,0,null,0],\"" + id + "\"," + ts + ",\"" + sg + "\"]";
            JSONArray req = new JSONArray().put(new JSONArray().put(new JSONArray()
                    .put("Fbv4je").put(dalam).put(JSONObject.NULL).put("generic")));
            String balas = ambilHttp("https://news.google.com/_/DotsSplashUi/data/batchexecute",
                    "f.req=" + java.net.URLEncoder.encode(req.toString(), "UTF-8"));
            String[] bagian = balas.split("\n\n");
            if (bagian.length < 2) return null;
            String isi = new JSONArray(bagian[1]).getJSONArray(0).getString(2);
            String u = new JSONArray(isi).getString(1);
            return u.startsWith("http") ? u : null;
        } catch (Exception e) {
            return null;
        }
    }

    // Coba ambil teks berkala sambil halaman masih dimuat, tidak menunggu iklan selesai.
    void jadwalAmbil() {
        h.postDelayed(() -> {
            if (selesai || isFinishing()) return;
            String u = web.getUrl();
            if (u != null && !u.contains("google.com") && !u.startsWith("about:")) ambilTeks();
            jadwalAmbil();
        }, 800);
    }

    void ikutiTautan() {
        if (selesai || sudahIkuti || isFinishing()) return;
        String u = web.getUrl();
        if (u == null || !u.contains("google.com")) return;
        sudahIkuti = true;
        web.evaluateJavascript("(function(){var a=document.querySelectorAll('a[href^=\"http\"]');"
                + "for(var i=0;i<a.length;i++){var x=a[i].href;if(x.indexOf('google.')<0&&x.indexOf('gstatic')<0)return x;}return '';})()", val -> {
            try {
                String x = new JSONArray("[" + val + "]").getString(0);
                if (x != null && x.startsWith("http")) web.loadUrl(x);
            } catch (Exception e) {
                // abaikan
            }
        });
    }

    void alihTampilan() {
        tampilAsli = !tampilAsli;
        if (tampilAsli) {
            gulung.setVisibility(View.GONE);
            web.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            btnAsli.setText("Kembali ke isi berita");
        } else {
            gulung.setVisibility(View.VISIBLE);
            web.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
            btnAsli.setText("Halaman asli");
        }
    }

    void ambilTeks() {
        if (selesai || isFinishing()) return;
        web.evaluateJavascript(JS, val -> {
            if (selesai || val == null) return;
            try {
                String teks = new JSONArray("[" + val + "]").getString(0);
                JSONObject o = new JSONObject(teks);
                String isiTeks = o.optString("isi");
                int n = isiTeks.length();
                // Tampilkan begitu halaman selesai, atau begitu panjang teks sudah tidak bertambah.
                boolean stabil = n == panjangLama;
                panjangLama = n;
                if (n > 400 && (stabil || progres >= 100)) {
                    tampilkan(isiTeks);
                    return;
                }
            } catch (Exception e) {
                // coba lagi di bawah
            }
            // percobaan ulang ditangani jadwalAmbil(); batas waktu ada di onCreate
        });
    }

    void gagal() {
        if (selesai || gagalTampil) return;
        gagalTampil = true;
        status.setText("Isi berita tidak bisa diambil dari situs ini." + (alasan.isEmpty() ? "" : "\n(" + alasan + ")"));
    }

    @Override
    public void onBackPressed() {
        if (tampilAsli) alihTampilan();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (web != null) {
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
