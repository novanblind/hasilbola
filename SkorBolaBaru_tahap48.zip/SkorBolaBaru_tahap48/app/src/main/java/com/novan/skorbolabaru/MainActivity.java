package com.novan.skorbolabaru;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final String[] KODE = {"BRT", "PL", "PD", "SA", "BL1", "FL1", "CL", "ID1", "TIM",
            "WC", "EC", "UNL", "FRI", "KPE", "KPA", "KPS", "KPF", "KPC", "KEU", "ASI", "AFR", "COP", "GLD", "CNL"};
    static final String[] NAMA = {
            "Berita (semua liga dan negara)",
            "Liga Inggris", "Liga Spanyol", "Liga Italia",
            "Liga Jerman", "Liga Prancis", "Liga Champions",
            "Liga 1 Indonesia", "Timnas Indonesia",
            "Piala Dunia", "Piala Eropa", "UEFA Nations League", "Laga persahabatan antar negara",
            "Kualifikasi Piala Dunia Eropa", "Kualifikasi Piala Dunia Asia", "Kualifikasi Piala Dunia Amerika Selatan",
            "Kualifikasi Piala Dunia Afrika", "Kualifikasi Piala Dunia CONCACAF", "Kualifikasi Piala Eropa",
            "Piala Asia", "Piala Afrika", "Copa America", "Gold Cup CONCACAF", "CONCACAF Nations League"};
    // Kompetisi antar negara yang datanya hanya dari ESPN (tanpa kunci). Piala Dunia dan Piala Eropa lewat football-data.org.
    static final Set<String> NEGARA = new HashSet<>(java.util.Arrays.asList(
            "UNL", "FRI", "KPE", "KPA", "KPS", "KPF", "KPC", "KEU", "ASI", "AFR", "COP", "GLD", "CNL"));
    static final String[] MODE = {"Klasemen", "Hasil", "Jadwal", "Sedang main", "Top skor", "Top assist", "Berita terbaru"};
    // Pilihan tampilan khusus untuk kategori Berita (semua liga dan negara): berapa hari ke belakang.
    static final String[] MODE_BRT = {"Hari ini", "1 hari ke belakang", "2 hari ke belakang", "3 hari ke belakang", "7 hari ke belakang"};
    static final int[] HARI_BRT = {1, 1, 2, 3, 7};
    static final String[] KUERI_BERITA = {
            "sepak bola",
            "Liga Inggris Premier League", "Liga Spanyol La Liga", "Liga Italia Serie A",
            "Bundesliga Liga Jerman", "Ligue 1 Liga Prancis", "Liga Champions UEFA",
            "BRI Liga 1 Indonesia", "Timnas Indonesia sepak bola",
            "Piala Dunia FIFA sepak bola", "Piala Eropa EURO sepak bola", "UEFA Nations League",
            "laga persahabatan timnas internasional sepak bola",
            "kualifikasi Piala Dunia zona Eropa", "kualifikasi Piala Dunia zona Asia timnas",
            "kualifikasi Piala Dunia zona Amerika Selatan", "kualifikasi Piala Dunia zona Afrika",
            "kualifikasi Piala Dunia zona CONCACAF", "kualifikasi Piala Eropa EURO",
            "Piala Asia AFC sepak bola", "Piala Afrika sepak bola", "Copa America sepak bola",
            "Gold Cup CONCACAF sepak bola", "CONCACAF Nations League"};
    final Map<String, String> beritaLink = new HashMap<>();
    // Berita dari tiga portal: dibuka di layar artikel (meniru aplikasi BeritaOnline).
    final Map<String, NewsItem> beritaItem = new HashMap<>();
    static final String FD = "https://api.football-data.org/v4/competitions/";
    // Kunci football-data.org datang dari GitHub Secrets (FD_KEY) saat build, lalu disamarkan (XOR + heks)
    // di APK; dibuka lagi saat dipakai. Rumusnya harus sama dengan di app/build.gradle.
    static final String FD_KEY = bukaKunci(BuildConfig.FD_ENC);

    static String bukaKunci(String h) {
        if (h == null || h.length() < 2) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i * 2 + 1 < h.length(); i++) {
            int v = Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
            sb.append((char) (v ^ (((i * 31 + 7) ^ 0x5A) & 0xFF)));
        }
        return sb.toString();
    }
    static final String ESPN = "https://site.api.espn.com/apis/site/v2/sports/soccer/";
    // Sumber pencetak gol (ESPN). null = tidak tersedia, jadi pakai TheSportsDB saat diketuk.
    static final String[] ESPN_LIGA = {null, "eng.1", "esp.1", "ita.1", "ger.1", "fra.1", "uefa.champions", "idn.1", null,
            "fifa.world", "uefa.euro", "uefa.nations", "fifa.friendly",
            "fifa.worldq.uefa", "fifa.worldq.afc", "fifa.worldq.conmebol", "fifa.worldq.caf", "fifa.worldq.concacaf",
            "uefa.euroq", "afc.asian.cup", "caf.nations", "conmebol.america", "concacaf.gold", "concacaf.nations.league"};
    static final String TSDB = "https://www.thesportsdb.com/api/v1/json/" + BuildConfig.TSDB_KEY + "/";

    static class GalatHttp extends Exception {
        final int kode;
        final String pesan;

        GalatHttp(int kode, String pesan) {
            this.kode = kode;
            this.pesan = pesan;
        }
    }

    SharedPreferences sp;
    int liga, mode;
    Button btnLiga, btnMode, btnSegar;
    TextView status;
    ArrayAdapter<String> adapter;
    final Handler ui = new Handler(Looper.getMainLooper());
    final ExecutorService io = Executors.newSingleThreadExecutor();
    volatile int permintaan = 0;
    List<String> refs = new ArrayList<>();
    final List<String> refsBuf = new ArrayList<>();
    final List<Tunda> tundaBuf = new ArrayList<>();
    final Map<String, String> detailBuf = new HashMap<>();
    Map<String, String> detailTeks = new HashMap<>();
    long terakhirMuat = 0;
    final Runnable auto = new Runnable() {
        @Override
        public void run() {
            if (modeLangsung()) muat(true);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences("skor", MODE_PRIVATE);
        // Daftar kompetisi bertambah satu di depan (Berita), jadi pilihan lama digeser satu.
        if (sp.contains("komp2")) liga = Math.min(sp.getInt("komp2", 1), KODE.length - 1);
        else liga = Math.min(sp.getInt("liga", 0) + 1, KODE.length - 1);
        mode = muatMode();
        btnLiga = findViewById(R.id.btnLiga);
        btnMode = findViewById(R.id.btnMode);
        btnSegar = findViewById(R.id.btnSegar);
        status = findViewById(R.id.status);
        ListView daftar = findViewById(R.id.daftar);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        daftar.setAdapter(adapter);
        daftar.setOnItemClickListener((p, v, pos, idb) -> {
            if (pos < refs.size() && !refs.get(pos).isEmpty()) detail(refs.get(pos));
        });
        labelTombol();

        btnLiga.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Pilih kompetisi")
                .setItems(NAMA, (d, i) -> gantiKomp(i)).show());

        btnMode.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Pilih tampilan")
                .setItems(daftarMode(), (d, i) -> {
                    mode = i;
                    simpanMode();
                    labelTombol();
                    muatBaru();
                }).show());

        btnSegar.setOnClickListener(v -> muat(true));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Setiap aplikasi dibuka (atau kembali ke depan), tampilan disegarkan otomatis.
        if (System.currentTimeMillis() - terakhirMuat > 2000) muat(true);
        else jadwalkan();
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(auto);
    }

    void labelTombol() {
        btnLiga.setText("Kompetisi: " + NAMA[liga]);
        btnMode.setText("Tampilan: " + namaMode(mode));
    }

    boolean beritaSemua() {
        return KODE[liga].equals("BRT");
    }

    String[] daftarMode() {
        return beritaSemua() ? MODE_BRT : MODE;
    }

    String namaMode(int m) {
        String[] d = daftarMode();
        return d[Math.max(0, Math.min(m, d.length - 1))];
    }

    // Pilihan tampilan Berita (hari) dan tampilan kompetisi lain disimpan terpisah.
    void simpanMode() {
        sp.edit().putInt(beritaSemua() ? "modeBrt3" : "mode10", mode).apply();
    }

    int muatMode() {
        return beritaSemua() ? Math.min(sp.getInt("modeBrt3", 0), MODE_BRT.length - 1)
                : Math.min(sp.getInt("mode10", 1), MODE.length - 1);
    }

    void gantiKomp(int baru) {
        boolean lamaBerita = beritaSemua();
        simpanMode();
        liga = baru;
        sp.edit().putInt("komp2", baru).apply();
        if (lamaBerita != beritaSemua()) mode = muatMode();
        labelTombol();
        muatBaru();
    }

    // Sedang main hanya ada di kompetisi biasa; di Berita, nomor 3 berarti 7 hari.
    boolean modeLangsung() {
        return !beritaSemua() && mode == 3;
    }

    void jadwalkan() {
        ui.removeCallbacks(auto);
        if (modeLangsung()) ui.postDelayed(auto, 60000);
    }

    void muat() {
        muat(false);
    }

    // Ganti liga/tampilan: daftar lama langsung dikosongkan dan data diambil baru, sama seperti tombol Segarkan.
    void muatBaru() {
        refs = new ArrayList<>();
        detailTeks = new HashMap<>();
        adapter.clear();
        muat(true);
    }

    void muat(boolean paksa) {
        if (paksa) {
            synchronized (CACHE) { CACHE.clear(); }
        }
        terakhirMuat = System.currentTimeMillis();
        final int id = ++permintaan;
        final String kode = KODE[liga];
        final int m = mode;
        final String judul = NAMA[liga] + ", " + namaMode(m);
        status.setText("Memuat...");
        io.execute(() -> {
            try {
                final List<String> baris = ambil(kode, m);
                final List<String> salinRef = new ArrayList<>(refsBuf);
                final Map<String, String> salinDetail = new HashMap<>(detailBuf);
                final List<Tunda> salinTunda = new ArrayList<>(tundaBuf);
                ui.post(() -> {
                    if (id != permintaan) return;
                    refs = salinRef;
                    detailTeks = salinDetail;
                    adapter.clear();
                    adapter.addAll(baris);
                    status.setText(judul);
                    jadwalkan();
                    if (!salinTunda.isEmpty()) lengkapiGol(id, kode, salinTunda);
                });
            } catch (GalatHttp g) {
                final String p = g.pesan != null ? g.pesan
                        : (g.kode == 400 || g.kode == 401 || g.kode == 403)
                        ? "Kunci salah, atau liga ini tidak ada di paket gratis."
                        : g.kode == 429 ? "Terlalu sering. Tunggu satu menit."
                        : "Gagal memuat. Coba lagi.";
                ui.post(() -> {
                    if (id == permintaan) {
                        refs = new ArrayList<>();
                        detailTeks = new HashMap<>();
                        adapter.clear();
                        status.setText(p);
                        jadwalkan();
                    }
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (id == permintaan) {
                        status.setText("Gagal memuat. Cek internet.");
                        jadwalkan();
                    }
                });
            }
        });
    }

    // Daftar gol yang belum ada di scoreboard diambil paralel (5 sekaligus), baris diperbarui begitu siap.
    // Tidak lewat antrean io, jadi ganti liga/tampilan tidak menunggu pengambilan ini selesai.
    void lengkapiGol(final int id, final String kode, final List<Tunda> daftarTunda) {
        final ExecutorService kolam = Executors.newFixedThreadPool(5);
        for (final Tunda t : daftarTunda) {
            kolam.execute(() -> {
                if (id != permintaan) return;
                isiRingkasan(kode, t.e);
                if (t.e.gol.isEmpty()) return;
                final String gol = ringkasGol(t.e, t.h1, t.a1);
                final String lengkap = t.head + "\n\n" + detailGol(t.e, t.h1, t.a1);
                ui.post(() -> {
                    if (id != permintaan || t.idx >= adapter.getCount()) return;
                    String lama = adapter.getItem(t.idx);
                    adapter.remove(lama);
                    adapter.insert(t.head + "\n" + gol, t.idx);
                    detailTeks.put(t.ref, lengkap);
                });
            });
        }
        kolam.shutdown();
    }

    List<String> ambil(String kode, int m) throws Exception {
        refsBuf.clear();
        detailBuf.clear();
        tundaBuf.clear();
        List<String> out;
        if (kode.equals("BRT")) out = ambilBeritaSemua(m);
        else if (m == 6) out = ambilBerita();
        else if (kode.equals("ID1") || kode.equals("TIM")) out = ambilTsdb(kode, m);
        else if (NEGARA.contains(kode)) out = ambilNegara(kode, m);
        // Liga Champions: hasil, jadwal, dan sedang main langsung dari ESPN (skor dan pencetak gol sudah ada di data yang sama).
        else if (kode.equals("CL") && m >= 1 && m <= 3) out = ambilNegara(kode, m);
        else out = ambilEropa(kode, m);
        if (out.isEmpty()) out.add(kode.equals("BRT") ? "Tidak ada berita." : m == 3 ? "Tidak ada yang sedang main." : "Tidak ada data.");
        return out;
    }

    // ---------- Liga Eropa (football-data.org) ----------

    List<String> ambilPencetak(String kode, int m) throws Exception {
        JSONObject o = new JSONObject(http(FD + kode + "/scorers?limit=50", FD_KEY));
        JSONArray a = o.optJSONArray("scorers");
        List<String> out = new ArrayList<>();
        if (a == null) return out;
        List<JSONObject> daftar = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.getJSONObject(i);
            if (m == 5) {
                if (x.isNull("assists") || x.optInt("assists") <= 0) continue;
            }
            daftar.add(x);
        }
        if (m == 5) {
            if (daftar.isEmpty()) {
                throw new GalatHttp(0, "Data assist belum tersedia dari sumber data untuk liga ini.");
            }
            Collections.sort(daftar, (x, y) -> y.optInt("assists") - x.optInt("assists"));
        }
        for (int i = 0; i < daftar.size() && out.size() < 20; i++) {
            JSONObject x = daftar.get(i);
            JSONObject pm = x.optJSONObject("player");
            String nm = pm == null ? "?" : pm.optString("name", "?");
            String tim = nama(x.optJSONObject("team"));
            String isi = (out.size() + 1) + ". " + nm + ", " + tim;
            if (m == 4) isi += ", gol " + x.optInt("goals");
            else isi += ", assist " + x.optInt("assists");
            out.add(isi);
        }
        if (m == 5) out.add("Assist hanya dihitung dari 50 pencetak gol teratas.");
        return out;
    }

    List<String> ambilEropa(String kode, int m) throws Exception {
        if (m >= 4) return ambilPencetak(kode, m);
        String path;
        switch (m) {
            case 0: path = "/standings"; break;
            case 1: path = "/matches?status=FINISHED"; break;
            case 2: path = "/matches?status=SCHEDULED,TIMED"; break;
            default: path = "/matches?status=IN_PLAY,PAUSED"; break;
        }
        JSONObject o = new JSONObject(http(FD + kode + path, FD_KEY));
        List<String> out = new ArrayList<>();
        if (m == 0) {
            JSONArray st = o.getJSONArray("standings");
            int total = 0;
            for (int i = 0; i < st.length(); i++) {
                if ("TOTAL".equals(st.getJSONObject(i).optString("type"))) total++;
            }
            for (int i = 0; i < st.length(); i++) {
                JSONObject s = st.getJSONObject(i);
                if (!"TOTAL".equals(s.optString("type"))) continue;
                if (total > 1 && !s.isNull("group")) out.add(s.optString("group").replace('_', ' '));
                JSONArray tb = s.getJSONArray("table");
                for (int j = 0; j < tb.length(); j++) {
                    JSONObject r = tb.getJSONObject(j);
                    out.add(r.optInt("position") + ". " + nama(r.getJSONObject("team"))
                            + ", poin " + r.optInt("points")
                            + ", main " + r.optInt("playedGames")
                            + ", menang " + r.optInt("won")
                            + ", seri " + r.optInt("draw")
                            + ", kalah " + r.optInt("lost")
                            + ", selisih gol " + r.optInt("goalDifference"));
                }
            }
        } else {
            JSONArray a = o.getJSONArray("matches");
            int n = a.length();
            if (m == 1) {
                List<JSONObject> terpilih = new ArrayList<>();
                for (int i = n - 1; i >= 0 && terpilih.size() < 20; i--) terpilih.add(a.getJSONObject(i));
                List<EvEspn> esp = new ArrayList<>();
                long min = Long.MAX_VALUE, max = 0;
                for (JSONObject mx : terpilih) {
                    long w = epochFd(mx.optString("utcDate"));
                    if (w > 0) { min = Math.min(min, w); max = Math.max(max, w); }
                }
                if (max > 0) esp = ambilEspn(kode, min, max);
                esp = lengkapiHari(kode, esp, terpilih);
                for (JSONObject mx : terpilih) {
                    String head = baris(mx, m);
                    JSONObject sc = mx.optJSONObject("score");
                    String h1 = nama(mx.optJSONObject("homeTeam")), a1 = nama(mx.optJSONObject("awayTeam"));
                    int sh = angka(skor(sc, "home")), sa = angka(skor(sc, "away"));
                    long w = epochFd(mx.optString("utcDate"));
                    String ref = "FD:" + mx.optInt("id");
                    String gol = isiBaris(esp, ref, head, h1, a1, nama2(mx.optJSONObject("homeTeam")),
                            nama2(mx.optJSONObject("awayTeam")), sh, sa, w, out.size());
                    out.add(gol.isEmpty() ? head : head + "\n" + gol);
                    refsBuf.add(ref);
                }
            } else {
                for (int i = 0; i < n && (m == 3 || out.size() < 20); i++) out.add(baris(a.getJSONObject(i), m));
            }
        }
        return out;
    }

    String baris(JSONObject x, int m) {
        String h = nama(x.optJSONObject("homeTeam"));
        String t = nama(x.optJSONObject("awayTeam"));
        if (m == 2) return tgl(x.optString("utcDate"), true) + ": " + h + " lawan " + t;
        JSONObject s = x.optJSONObject("score");
        String sk = h + " " + skor(s, "home") + ", " + t + " " + skor(s, "away");
        if (m == 1) return tgl(x.optString("utcDate"), false) + ": " + sk;
        return sk + ("PAUSED".equals(x.optString("status")) ? ", turun minum" : ", sedang main");
    }

    static String skor(JSONObject s, String sisi) {
        if (s == null) return "0";
        JSONObject ft = s.optJSONObject("fullTime");
        if (ft == null || ft.isNull(sisi)) return "0";
        return String.valueOf(ft.optInt(sisi));
    }

    static String nama(JSONObject t) {
        if (t == null) return "?";
        String n = t.optString("name", "");
        if (n.isEmpty() || "null".equals(n)) n = t.optString("shortName", "");
        if (n.isEmpty() || "null".equals(n)) return "?";
        return jelas(n);
    }

    // Nama tim yang enak dibaca pembaca layar: nama lengkap tanpa singkatan (bukan "Barça", "Man City", "Spurs").
    static final HashMap<String, String> TIM = new HashMap<>();
    static {
        String[] p = {
            "brighton & hove albion fc", "Brighton",
            "wolverhampton wanderers fc", "Wolverhampton",
            "club atlético de madrid", "Atletico Madrid",
            "athletic club", "Athletic Bilbao",
            "real betis balompié", "Real Betis",
            "real sociedad de fútbol", "Real Sociedad",
            "rc celta de vigo", "Celta Vigo",
            "rcd espanyol de barcelona", "Espanyol",
            "rayo vallecano de madrid", "Rayo Vallecano",
            "deportivo alavés", "Alaves",
            "fc internazionale milano", "Inter Milan",
            "ac milan", "AC Milan",
            "ac pisa 1909", "Pisa",
            "hellas verona fc", "Verona",
            "fc bayern münchen", "Bayern Munchen",
            "hamburger sv", "Hamburg",
            "1. fc köln", "Koln",
            "borussia mönchengladbach", "Monchengladbach",
            "olympique de marseille", "Marseille",
            "olympique lyonnais", "Lyon",
            "racing club de strasbourg alsace", "Strasbourg",
            "stade brestois 29", "Brest",
            "stade rennais fc 1901", "Rennes",
            "sporting clube de portugal", "Sporting Lisbon",
            "sl benfica", "Benfica",
            "fc københavn", "Kobenhavn",
            "fk bodø/glimt", "Bodo Glimt",
            "club brugge kv", "Club Brugge",
            "union saint-gilloise", "Union Saint-Gilloise",
            "adhyaksa fc", "Isen Mulang Kalteng",
            "adhyaksa", "Isen Mulang Kalteng",
            "malut united fc", "Java United",
            "malut united", "Java United",
            "isen mulang fc", "Isen Mulang Kalteng"
        };
        for (int i = 0; i + 1 < p.length; i += 2) TIM.put(p[i], p[i + 1]);
    }

    // Nama negara dalam bahasa Indonesia supaya enak dibaca pembaca layar.
    static {
        String[] n = {
            "germany", "Jerman", "spain", "Spanyol", "france", "Prancis", "england", "Inggris",
            "scotland", "Skotlandia", "northern ireland", "Irlandia Utara", "republic of ireland", "Irlandia",
            "ireland", "Irlandia", "netherlands", "Belanda", "belgium", "Belgia", "switzerland", "Swiss",
            "sweden", "Swedia", "norway", "Norwegia", "finland", "Finlandia", "poland", "Polandia",
            "czechia", "Ceko", "czech republic", "Ceko", "slovakia", "Slowakia", "croatia", "Kroasia",
            "bosnia and herzegovina", "Bosnia", "bosnia-herzegovina", "Bosnia", "north macedonia", "Makedonia Utara",
            "greece", "Yunani", "turkey", "Turki", "türkiye", "Turki", "turkiye", "Turki", "romania", "Rumania",
            "hungary", "Hungaria", "ukraine", "Ukraina", "russia", "Rusia", "lithuania", "Lituania",
            "iceland", "Islandia", "cyprus", "Siprus", "luxembourg", "Luksemburg", "italy", "Italia",
            "faroe islands", "Kepulauan Faroe",
            "japan", "Jepang", "south korea", "Korea Selatan", "korea republic", "Korea Selatan",
            "north korea", "Korea Utara", "korea dpr", "Korea Utara", "china", "Tiongkok", "china pr", "Tiongkok",
            "saudi arabia", "Arab Saudi", "iraq", "Irak", "united arab emirates", "Uni Emirat Arab",
            "jordan", "Yordania", "syria", "Suriah", "palestine", "Palestina", "yemen", "Yaman",
            "kyrgyzstan", "Kirgistan", "singapore", "Singapura", "philippines", "Filipina", "cambodia", "Kamboja",
            "chinese taipei", "Taiwan", "maldives", "Maladewa", "timor-leste", "Timor Leste", "east timor", "Timor Leste",
            "egypt", "Mesir", "morocco", "Maroko", "algeria", "Aljazair", "cameroon", "Kamerun",
            "ivory coast", "Pantai Gading", "côte d'ivoire", "Pantai Gading", "cote d'ivoire", "Pantai Gading",
            "south africa", "Afrika Selatan", "dr congo", "Kongo", "congo dr", "Kongo", "congo", "Kongo",
            "ethiopia", "Etiopia", "cape verde", "Tanjung Verde", "cabo verde", "Tanjung Verde",
            "equatorial guinea", "Guinea Khatulistiwa", "comoros", "Komoro", "mozambique", "Mozambik",
            "united states", "Amerika Serikat", "usa", "Amerika Serikat", "mexico", "Meksiko", "canada", "Kanada",
            "brazil", "Brasil", "colombia", "Kolombia", "ecuador", "Ekuador", "chile", "Cile",
            "jamaica", "Jamaika", "trinidad and tobago", "Trinidad dan Tobago", "cuba", "Kuba",
            "new zealand", "Selandia Baru", "new caledonia", "Kaledonia Baru", "papua new guinea", "Papua Nugini",
            "solomon islands", "Kepulauan Solomon"
        };
        for (int i = 0; i + 1 < n.length; i += 2) TIM.put(n[i], n[i + 1]);
    }

    static final Set<String> BUANG_TIM = new HashSet<>(java.util.Arrays.asList(
            "fc", "afc", "cf", "sc", "as", "ss", "ssc", "us", "rc", "rcd", "ca", "cd", "ud", "sd",
            "sv", "vfb", "vfl", "tsg", "fsv", "ogc", "sk", "fk", "bk", "cfc", "acf", "bc", "calcio",
            "kv", "1.", "&"));

    static String jelas(String n) {
        n = n.trim();
        String m = TIM.get(n.toLowerCase(Locale.ROOT));
        if (m != null) return m;
        StringBuilder sb = new StringBuilder();
        for (String w : n.split("\\s+")) {
            String k = w.toLowerCase(Locale.ROOT);
            if (BUANG_TIM.contains(k) || k.matches("\\d+")) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(w);
        }
        return sb.length() == 0 ? n : sb.toString();
    }

    static String tgl(String iso, boolean jam) {
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = in.parse(iso);
            SimpleDateFormat out = new SimpleDateFormat(jam ? "d MMM HH.mm" : "d MMM", new Locale("id", "ID"));
            return out.format(d);
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- Liga Indonesia dan Timnas (TheSportsDB) ----------

    List<String> ambilTsdb(String kode, int m) throws Exception {
        boolean tim = kode.equals("TIM");
        if (m == 3) throw new GalatHttp(0, "Skor langsung belum ada untuk pilihan ini.");
        if (m >= 4) throw new GalatHttp(0, "Top skor dan top assist belum tersedia untuk liga atau tim ini.");
        if (tim && m == 0) throw new GalatHttp(0, "Timnas tidak punya klasemen.");
        String id = tim ? cariTim() : cariLiga(kode);
        if (id == null) throw new GalatHttp(0, "Tidak ditemukan di sumber data.");
        List<String> out = new ArrayList<>();
        if (m == 0) {
            // TheSportsDB gratis hanya memberi 5 klub, jadi klasemen lengkap diambil dari ESPN lebih dulu.
            if (!tim && espnKode(kode) != null) {
                List<String> lengkap = klasemenEspn(espnKode(kode));
                if (!lengkap.isEmpty()) return lengkap;
            }
            JSONArray tb = null;
            for (String s : musim()) {
                JSONObject o = new JSONObject(http(TSDB + "lookuptable.php?l=" + id + "&s=" + s, null));
                tb = o.optJSONArray("table");
                if (tb != null && tb.length() > 0) break;
            }
            if (tb != null) {
                for (int i = 0; i < tb.length(); i++) {
                    JSONObject r = tb.getJSONObject(i);
                    out.add(r.optString("intRank") + ". " + jelas(r.optString("strTeam"))
                            + ", poin " + r.optString("intPoints")
                            + ", main " + r.optString("intPlayed")
                            + ", menang " + r.optString("intWin")
                            + ", seri " + r.optString("intDraw")
                            + ", kalah " + r.optString("intLoss")
                            + ", selisih gol " + r.optString("intGoalDifference"));
                }
            }
        } else {
            String path = tim
                    ? (m == 1 ? "eventslast.php?id=" : "eventsnext.php?id=")
                    : (m == 1 ? "eventspastleague.php?id=" : "eventsnextleague.php?id=");
            JSONObject o = new JSONObject(http(TSDB + path + id, null));
            JSONArray a = o.optJSONArray("results");
            if (a == null) a = o.optJSONArray("events");
            List<JSONObject> ev = new ArrayList<>();
            if (a != null) {
                for (int i = 0; i < a.length(); i++) ev.add(a.getJSONObject(i));
            }
            Collections.sort(ev, (x, y) -> waktu(x).compareTo(waktu(y)));
            if (m == 1) Collections.reverse(ev);
            List<EvEspn> esp = new ArrayList<>();
            if (m == 1 && espnKode(kode) != null) {
                long min = Long.MAX_VALUE, max = 0;
                for (int i = 0; i < ev.size() && i < 20; i++) {
                    long w = epochTsdb(ev.get(i));
                    if (w > 0) { min = Math.min(min, w); max = Math.max(max, w); }
                }
                if (max > 0) esp = ambilEspn(kode, min, max);
            }
            for (JSONObject x : ev) {
                if (out.size() >= 20) break;
                String head = barisTsdb(x, m);
                String gol = "";
                String ref = "TS:" + x.optString("idEvent");
                if (m == 1 && !esp.isEmpty()) {
                    String hn = jelas(x.optString("strHomeTeam", "?")), an = jelas(x.optString("strAwayTeam", "?"));
                    gol = isiBaris(esp, ref, head, hn, an, hn, an, angka(sk(x, "intHomeScore")),
                            angka(sk(x, "intAwayScore")), epochTsdb(x), out.size());
                }
                out.add(gol.isEmpty() ? head : head + "\n" + gol);
                if (m == 1) refsBuf.add(ref);
            }
        }
        return out;
    }

    List<String> klasemenEspn(String liga) {
        List<String> out = new ArrayList<>();
        try {
            // Musim berjalan: mulai Juli tahun ini; sebelum Juli masih musim yang dimulai tahun lalu.
            Calendar c = Calendar.getInstance();
            int musimIni = c.get(Calendar.MONTH) >= Calendar.JULY ? c.get(Calendar.YEAR) : c.get(Calendar.YEAR) - 1;
            String u = "https://site.api.espn.com/apis/v2/sports/soccer/" + liga + "/standings?season=" + musimIni;
            JSONObject o = new JSONObject(http(u, null));
            JSONArray ch = o.optJSONArray("children");
            JSONObject st = null;
            if (ch != null && ch.length() > 0) st = ch.getJSONObject(0).optJSONObject("standings");
            if (st == null) st = o.optJSONObject("standings");
            if (st == null) return out;
            // Jika ESPN mengembalikan musim lain (misalnya musim lalu), buang supaya tidak tampil klasemen lama.
            if (st.has("season") && st.optInt("season", musimIni) != musimIni) return out;
            JSONArray en = st.optJSONArray("entries");
            if (en == null) return out;
            List<String[]> baris = new ArrayList<>();
            for (int i = 0; i < en.length(); i++) {
                baris.add(entriKlasemen(en.getJSONObject(i), i));
            }
            Collections.sort(baris, (x, y) -> angka(x[0]) - angka(y[0]));
            for (String[] b : baris) out.add(teksKlasemen(b));
        } catch (Exception ex) {
            out.clear();
        }
        return out;
    }

    // Satu baris klasemen ESPN: {peringkat, nama, poin, main, menang, seri, kalah, selisih gol}.
    static String[] entriKlasemen(JSONObject e, int i) {
        JSONObject tm = e.optJSONObject("team");
        String nm = tm == null ? "?" : tm.optString("displayName", tm.optString("name", "?"));
        Map<String, String> v = new HashMap<>();
        JSONArray sa = e.optJSONArray("stats");
        if (sa != null) {
            for (int j = 0; j < sa.length(); j++) {
                JSONObject x = sa.optJSONObject(j);
                if (x != null) v.put(x.optString("name"), x.optString("displayValue", x.optString("value")));
            }
        }
        String rank = v.containsKey("rank") ? v.get("rank") : String.valueOf(i + 1);
        String gd = v.containsKey("pointDifferential") ? v.get("pointDifferential") : v.containsKey("goalDifference") ? v.get("goalDifference") : "0";
        if (gd.startsWith("+")) gd = gd.substring(1);
        return new String[]{rank, nm, v.containsKey("points") ? v.get("points") : "0",
                v.containsKey("gamesPlayed") ? v.get("gamesPlayed") : "0",
                v.containsKey("wins") ? v.get("wins") : "0",
                v.containsKey("ties") ? v.get("ties") : (v.containsKey("draws") ? v.get("draws") : "0"),
                v.containsKey("losses") ? v.get("losses") : "0", gd};
    }

    static String teksKlasemen(String[] b) {
        return b[0] + ". " + jelas(b[1]) + ", poin " + b[2] + ", main " + b[3] + ", menang " + b[4]
                + ", seri " + b[5] + ", kalah " + b[6] + ", selisih gol " + b[7];
    }

    // ---------- Kompetisi antar negara (ESPN) ----------

    static String tglEpoch(long t, boolean jam) {
        return new SimpleDateFormat(jam ? "d MMM HH.mm" : "d MMM", new Locale("id", "ID")).format(new Date(t));
    }

    static List<EvEspn> saringStatus(List<EvEspn> a, String state) {
        List<EvEspn> r = new ArrayList<>();
        for (EvEspn e : a) if (state.equals(e.state)) r.add(e);
        return r;
    }

    List<String> ambilNegara(String kode, int m) throws Exception {
        String slug = espnKode(kode);
        if (slug == null) throw new GalatHttp(0, "Kompetisi ini belum tersedia.");
        if (m >= 4) return topNegara(kode, slug, m);
        if (m == 0) return klasemenNegara(slug);
        final long hari = 86400000L;
        long skrg = System.currentTimeMillis();
        String state = m == 1 ? "post" : m == 2 ? "pre" : "in";
        List<EvEspn> pilih = new ArrayList<>();
        Set<String> sudah = new HashSet<>();
        String gagal = "";
        boolean adaBerhasil = false;
        // ESPN menolak permintaan rentang tanggal, jadi diambil per hari. Sedang main: kemarin dan hari ini.
        // Hasil: mundur dari hari ini; jadwal: maju dari hari ini; per 30 hari sekaligus sampai terkumpul 20 (maksimal 360 hari).
        int potong = m == 3 ? 1 : 12;
        int lebar = m == 3 ? 2 : 30;
        ExecutorService kolam = Executors.newFixedThreadPool(16);
        try {
            final String slugF = slug;
            for (int k = 0; k < potong && (m == 3 || pilih.size() < 20); k++) {
                List<java.util.concurrent.Callable<List<EvEspn>>> tugas = new ArrayList<>();
                for (int d = 0; d < lebar; d++) {
                    int geser = k * lebar + d;
                    final long t = m == 1 ? skrg - geser * hari : m == 2 ? skrg + geser * hari : skrg - (1 - d) * hari;
                    tugas.add(() -> unduhEspn(slugF, tglEspn(t), false));
                }
                alasanEspn = "";
                for (java.util.concurrent.Future<List<EvEspn>> f : kolam.invokeAll(tugas)) {
                    List<EvEspn> semua = f.get();
                    if (semua.isEmpty()) continue;
                    adaBerhasil = true;
                    for (EvEspn e : saringStatus(semua, state)) if (e.id.isEmpty() || sudah.add(e.id)) pilih.add(e);
                }
                if (!adaBerhasil && !alasanEspn.isEmpty()) { gagal = alasanEspn; break; }
            }
        } finally {
            kolam.shutdown();
        }
        if (!adaBerhasil && !gagal.isEmpty()) throw new GalatHttp(0, "Gagal memuat (" + gagal + "). Coba lagi.");
        final boolean turun = m == 1;
        Collections.sort(pilih, (x, y) -> turun ? Long.compare(y.waktu, x.waktu) : Long.compare(x.waktu, y.waktu));
        List<String> out = new ArrayList<>();
        for (EvEspn e : pilih) {
            if (m != 3 && out.size() >= 20) break;
            String h = jelas(e.tampilH.isEmpty() ? "?" : e.tampilH), a = jelas(e.tampilA.isEmpty() ? "?" : e.tampilA);
            if (m == 2) {
                out.add(tglEpoch(e.waktu, true) + ": " + h + " lawan " + a);
                continue;
            }
            String sk = h + " " + Math.max(0, e.skorH) + ", " + a + " " + Math.max(0, e.skorA);
            if (m == 3) {
                String ket = "STATUS_HALFTIME".equals(e.statusNama) ? ", turun minum"
                        : ", sedang main" + (e.jam.isEmpty() ? "" : ", menit " + e.jam);
                out.add(sk + ket);
                continue;
            }
            String head = tglEpoch(e.waktu, false) + ": " + sk;
            String ref = "ES:" + e.id;
            refsBuf.add(ref);
            if (!e.gol.isEmpty()) {
                out.add(head + "\n" + ringkasGol(e, h, a));
                detailBuf.put(ref, head + "\n\n" + detailGol(e, h, a));
            } else if (Math.max(0, e.skorH) + Math.max(0, e.skorA) == 0) {
                out.add(head);
                detailBuf.put(ref, head + "\n\nTidak ada gol.");
            } else {
                Tunda t = new Tunda();
                t.idx = out.size(); t.e = e; t.h1 = h; t.a1 = a; t.head = head; t.ref = ref;
                tundaBuf.add(t);
                out.add(head);
                detailBuf.put(ref, head + "\n\nNama pencetak gol belum tersedia untuk pertandingan ini.");
            }
        }
        return out;
    }

    List<String> klasemenNegara(String slug) throws Exception {
        List<String> out = new ArrayList<>();
        JSONObject o;
        try {
            o = new JSONObject(http("https://site.api.espn.com/apis/v2/sports/soccer/" + slug + "/standings", null));
        } catch (GalatHttp g) {
            if (g.kode == 400 || g.kode == 404) throw new GalatHttp(0, "Kompetisi ini tidak punya klasemen.");
            throw g;
        }
        JSONArray ch = o.optJSONArray("children");
        if (ch != null && ch.length() > 0) {
            for (int i = 0; i < ch.length(); i++) {
                JSONObject c = ch.getJSONObject(i);
                tambahKlasemen(out, c.optJSONObject("standings"),
                        ch.length() > 1 ? c.optString("name", "").replace("Group", "Grup") : "");
            }
        } else {
            tambahKlasemen(out, o.optJSONObject("standings"), "");
        }
        if (out.isEmpty()) throw new GalatHttp(0, "Kompetisi ini tidak punya klasemen.");
        return out;
    }

    static void tambahKlasemen(List<String> out, JSONObject st, String judulGrup) {
        if (st == null) return;
        JSONArray en = st.optJSONArray("entries");
        if (en == null || en.length() == 0) return;
        List<String[]> baris = new ArrayList<>();
        for (int i = 0; i < en.length(); i++) {
            JSONObject e = en.optJSONObject(i);
            if (e != null) baris.add(entriKlasemen(e, i));
        }
        Collections.sort(baris, (x, y) -> angka(x[0]) - angka(y[0]));
        if (!judulGrup.isEmpty()) out.add(judulGrup);
        for (String[] b : baris) out.add(teksKlasemen(b));
    }


    // ---------- Top skor dan top assist kompetisi antar negara (dihitung dari pertandingan yang sudah selesai di ESPN) ----------

    static class Pemain {
        String nama, tim;
        int n;
    }

    static void tambahPemain(Map<String, Pemain> peta, String nama, String tim) {
        if (nama == null || nama.isEmpty() || "?".equals(nama)) return;
        String kunci = nama + "|" + tim;
        synchronized (peta) {
            Pemain p = peta.get(kunci);
            if (p == null) {
                p = new Pemain();
                p.nama = nama;
                p.tim = tim;
                peta.put(kunci, p);
            }
            p.n++;
        }
    }

    static String timGol(EvEspn e, String tid, String h, String a) {
        if (!tid.isEmpty() && tid.equals(e.idA)) return a;
        if (!tid.isEmpty() && tid.equals(e.idH)) return h;
        return "";
    }

    static final java.util.regex.Pattern POLA_ASSIST = java.util.regex.Pattern.compile(
            "Assisted by (.+?)(?: with | following | from | after | on the | to the |\\.|$)");

    // Pemberi assist dari ringkasan pertandingan ESPN: teks "Assisted by ..." atau pemain kedua di peristiwa gol.
    void kumpulAssist(String slug, EvEspn e, String h, String a, Map<String, Pemain> peta) {
        try {
            JSONObject o = new JSONObject(http(ESPN + slug + "/summary?event=" + e.id, null));
            JSONArray ke = o.optJSONArray("keyEvents");
            if (ke == null) return;
            for (int i = 0; i < ke.length(); i++) {
                JSONObject k = ke.getJSONObject(i);
                JSONObject ty = k.optJSONObject("type");
                String tt = ty == null ? "" : (ty.optString("text", "") + " " + ty.optString("type", "")).toLowerCase(Locale.ROOT);
                boolean skor;
                if (k.has("scoringPlay")) skor = k.optBoolean("scoringPlay", false);
                else skor = (tt.contains("goal") && !tt.contains("disallow") && !tt.contains("no goal"))
                        || tt.contains("penalty - scored") || tt.contains("penalty---scored");
                if (!skor || tt.contains("shootout") || k.optBoolean("shootout", false)) continue;
                Gol g = golDariJson(k);
                if (g.bd) continue;
                String nm = "";
                java.util.regex.Matcher mt = POLA_ASSIST.matcher(k.optString("text", ""));
                if (mt.find()) nm = mt.group(1).trim();
                if (nm.isEmpty()) {
                    JSONArray at = k.optJSONArray("participants");
                    if (at == null) at = k.optJSONArray("athletesInvolved");
                    if (at != null && at.length() > 1) {
                        JSONObject p = at.optJSONObject(1);
                        if (p != null) {
                            nm = p.optString("displayName", "");
                            if (nm.isEmpty()) {
                                JSONObject ath = p.optJSONObject("athlete");
                                if (ath != null) nm = ath.optString("displayName", "");
                            }
                        }
                    }
                }
                if (!nm.isEmpty()) tambahPemain(peta, nm, timGol(e, g.tid, h, a));
            }
        } catch (Exception ex) {
            // satu pertandingan gagal tidak boleh merusak seluruh daftar
        }
    }

    // m: 4 = top skor, 5 = top assist. Pertandingan selesai dikumpulkan mundur per 30 hari,
    // berhenti kalau satu periode 30 hari kosong (jeda antar musim) atau sudah cukup jauh ke belakang.
    List<String> topNegara(final String kode, String slug, int m) throws Exception {
        final boolean assist = m == 5;
        final long hari = 86400000L;
        long skrg = System.currentTimeMillis();
        final int lebar = 30;
        int maks = slug.equals("fifa.friendly") ? 4 : 14;
        List<EvEspn> selesai = new ArrayList<>();
        Set<String> sudah = new HashSet<>();
        boolean adaBerhasil = false, ketemu = false;
        String gagal = "";
        ExecutorService kolam = Executors.newFixedThreadPool(16);
        try {
            final String slugF = slug;
            for (int k = 0; k < maks; k++) {
                List<java.util.concurrent.Callable<List<EvEspn>>> tugas = new ArrayList<>();
                for (int d = 0; d < lebar; d++) {
                    final long t = skrg - (k * lebar + d) * hari;
                    tugas.add(() -> unduhEspn(slugF, tglEspn(t), false));
                }
                alasanEspn = "";
                int baru = 0;
                for (java.util.concurrent.Future<List<EvEspn>> f : kolam.invokeAll(tugas)) {
                    List<EvEspn> semua = f.get();
                    if (semua.isEmpty()) continue;
                    adaBerhasil = true;
                    for (EvEspn e : saringStatus(semua, "post")) {
                        if (e.id.isEmpty() || sudah.add(e.id)) {
                            selesai.add(e);
                            baru++;
                        }
                    }
                }
                if (!adaBerhasil && !alasanEspn.isEmpty()) { gagal = alasanEspn; break; }
                if (baru > 0) ketemu = true;
                else if (ketemu || k >= 8) break;
            }
        } finally {
            kolam.shutdown();
        }
        if (selesai.isEmpty()) {
            if (!adaBerhasil && !gagal.isEmpty()) throw new GalatHttp(0, "Gagal memuat (" + gagal + "). Coba lagi.");
            throw new GalatHttp(0, "Belum ada pertandingan selesai untuk kompetisi ini.");
        }
        final Map<String, Pemain> peta = new HashMap<>();
        long awal = Long.MAX_VALUE;
        ExecutorService kolam2 = Executors.newFixedThreadPool(12);
        try {
            final String slugF = slug;
            List<java.util.concurrent.Callable<Void>> kerja = new ArrayList<>();
            for (final EvEspn e : selesai) {
                if (e.waktu > 0) awal = Math.min(awal, e.waktu);
                if (Math.max(0, e.skorH) + Math.max(0, e.skorA) == 0) continue;
                kerja.add(() -> {
                    String h = jelas(e.tampilH.isEmpty() ? "?" : e.tampilH), a = jelas(e.tampilA.isEmpty() ? "?" : e.tampilA);
                    if (assist) {
                        kumpulAssist(slugF, e, h, a, peta);
                    } else {
                        if (e.gol.isEmpty()) isiRingkasan(kode, e);
                        for (Gol g : e.gol) {
                            if (g.bd) continue;
                            tambahPemain(peta, g.nama, timGol(e, g.tid, h, a));
                        }
                    }
                    return null;
                });
            }
            kolam2.invokeAll(kerja);
        } finally {
            kolam2.shutdown();
        }
        List<Pemain> daftar = new ArrayList<>(peta.values());
        Collections.sort(daftar, (x, y) -> x.n != y.n ? y.n - x.n : x.nama.compareTo(y.nama));
        if (daftar.isEmpty()) {
            throw new GalatHttp(0, assist ? "Data assist belum tersedia dari sumber data untuk kompetisi ini."
                    : "Data pencetak gol belum tersedia dari sumber data untuk kompetisi ini.");
        }
        List<String> out = new ArrayList<>();
        for (int i = 0; i < daftar.size() && i < 20; i++) {
            Pemain p = daftar.get(i);
            out.add((i + 1) + ". " + p.nama + (p.tim.isEmpty() ? "" : ", " + p.tim)
                    + (assist ? ", assist " : ", gol ") + p.n);
        }
        out.add("Dihitung dari " + selesai.size() + " pertandingan selesai" + (awal == Long.MAX_VALUE ? "" : ", sejak " + tglEpoch(awal, false))
                + (assist ? ". Assist hanya dihitung kalau tercatat di sumber data." : "."));
        return out;
    }

    // ---------- Berita semua liga dan negara (Google News RSS), beberapa hari ke belakang ----------

    static class Brt {
        String judul = "", link = "", sumber = "", desc = "";
        long t;
        int akurasi; // 0 tanpa waktu, 1 hanya tanggal, 2 waktu tepat
    }

    static List<Brt> uraiBerita(String xml) {
        List<Brt> out = new ArrayList<>();
        SimpleDateFormat f = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
        java.util.regex.Matcher mi = java.util.regex.Pattern.compile("<item>(.*?)</item>", java.util.regex.Pattern.DOTALL).matcher(xml);
        while (mi.find()) {
            String it = mi.group(1);
            Brt b = new Brt();
            b.judul = tag(it, "title");
            b.link = tag(it, "link");
            b.sumber = tag(it, "source");
            if (b.judul.isEmpty()) continue;
            if (!b.sumber.isEmpty() && b.judul.endsWith(" - " + b.sumber)) {
                b.judul = b.judul.substring(0, b.judul.length() - b.sumber.length() - 3);
            }
            try { b.t = f.parse(tag(it, "pubDate")).getTime(); } catch (Exception e) { b.t = 0; }
            out.add(b);
        }
        return out;
    }

    // Berita olahraga dari tiga portal: CNN Indonesia (RSS olahraga), detikSport, dan Kompas Bola.
    static long waktuRss(String d) {
        try {
            return new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US).parse(d).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    // Waktu terbit detikSport dari data di dekat tautannya di halaman daftar ("d-time" atau "x menit lalu"); 0 kalau tidak ada.
    static long waktuDekat(String html, String link, long sekarang) {
        try {
            String path = link.replaceFirst("^https?://[^/]+", "");
            if (path.length() < 8) return 0;
            int i = html.indexOf(path);
            if (i < 0) return 0;
            String w = html.substring(i, Math.min(html.length(), i + 600));
            java.util.regex.Matcher a = java.util.regex.Pattern.compile("d-time=\"(\\d{9,13})\"").matcher(w);
            if (a.find()) {
                long v = Long.parseLong(a.group(1));
                return v < 100000000000L ? v * 1000 : v;
            }
            java.util.regex.Matcher r = java.util.regex.Pattern.compile("(\\d+)\\s*(menit|jam|hari)\\s*(yang\\s*)?lalu",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(w);
            if (r.find()) {
                long n = Long.parseLong(r.group(1));
                String u = r.group(2).toLowerCase(Locale.ROOT);
                return sekarang - n * (u.equals("menit") ? 60000L : u.equals("jam") ? 3600000L : 86400000L);
            }
        } catch (Exception e) {
            // tanpa waktu
        }
        return 0;
    }

    static List<Brt> daftarPortal(String html, String nama, String kode, long sekarang) {
        List<Brt> out = new ArrayList<>();
        int urut = 0;
        for (NewsItem n : NewsParser.parseNews(html, kode)) {
            Brt b = new Brt();
            b.judul = n.title;
            b.link = n.link;
            b.sumber = nama;
            b.desc = n.desc == null ? "" : n.desc;
            if (kode.equals("CNN")) {
                b.t = waktuRss(n.date);
                if (b.t > 0) b.akurasi = 2;
            } else if (kode.equals("Kompas")) {
                // Tanggal ada di alamat berita: /read/2026/11/17/...
                java.util.regex.Matcher mk = java.util.regex.Pattern.compile("/read/(\\d{4})/(\\d{2})/(\\d{2})/").matcher(n.link);
                if (mk.find()) {
                    Calendar c = Calendar.getInstance();
                    c.clear();
                    c.set(Integer.parseInt(mk.group(1)), Integer.parseInt(mk.group(2)) - 1, Integer.parseInt(mk.group(3)), 23, 59, 59);
                    b.t = Math.min(sekarang, c.getTimeInMillis());
                    b.akurasi = 1;
                }
            } else {
                b.t = waktuDekat(html, n.link, sekarang);
                if (b.t > 0) b.akurasi = 2;
            }
            if (b.t <= 0) {
                // Tanpa waktu: ikuti urutan halaman (paling atas paling baru).
                b.t = sekarang - urut * 60000L;
                b.akurasi = 0;
            }
            urut++;
            out.add(b);
        }
        return out;
    }

    List<String> ambilBeritaSemua(int m) throws Exception {
        final int hari = HARI_BRT[Math.max(0, Math.min(m, HARI_BRT.length - 1))];
        final long sekarang = System.currentTimeMillis();
        // Hari ini: sejak pukul 00.00 waktu setempat; lainnya: mundur sekian hari dari sekarang.
        long batasHariIni = sekarang - hari * 86400000L;
        if (m == 0) {
            Calendar c0 = Calendar.getInstance();
            c0.set(Calendar.HOUR_OF_DAY, 0);
            c0.set(Calendar.MINUTE, 0);
            c0.set(Calendar.SECOND, 0);
            c0.set(Calendar.MILLISECOND, 0);
            batasHariIni = c0.getTimeInMillis();
        }
        final long batas = batasHariIni;
        final String[][] sumber = {
                {"CNN Indonesia", "https://www.cnnindonesia.com/olahraga/rss", "CNN"},
                {"detikSport", "https://sport.detik.com", "Detik"},
                {"Kompas.com", "https://bola.kompas.com", "Kompas"}};
        List<Brt> semua = new ArrayList<>();
        int berhasil = 0;
        ExecutorService kolam = Executors.newFixedThreadPool(3);
        try {
            List<java.util.concurrent.Callable<List<Brt>>> tugas = new ArrayList<>();
            for (final String[] sm : sumber) {
                tugas.add(() -> {
                    String html = Http.get(sm[1], 3, 10000, null);
                    if (html == null) throw new GalatHttp(0, null);
                    return daftarPortal(html, sm[0], sm[2], sekarang);
                });
            }
            for (java.util.concurrent.Future<List<Brt>> f : kolam.invokeAll(tugas)) {
                try {
                    semua.addAll(f.get());
                    berhasil++;
                } catch (Exception ignore) {
                }
            }
        } finally {
            kolam.shutdown();
        }
        if (berhasil == 0) throw new GalatHttp(0, "Gagal memuat berita. Cek internet.");
        Collections.sort(semua, (x, y) -> Long.compare(y.t, x.t));
        beritaLink.clear();
        beritaItem.clear();
        List<String> out = new ArrayList<>();
        Set<String> linkAda = new HashSet<>(), judulAda = new HashSet<>();
        for (Brt b : semua) {
            if (out.size() >= 300) break;
            if (b.t < batas) continue;
            if (!b.link.isEmpty() && !linkAda.add(b.link)) continue;
            if (!judulAda.add(b.judul.toLowerCase(Locale.ROOT))) continue;
            String waktu = b.akurasi == 2 ? lalu(sekarang - b.t) : b.akurasi == 1 ? tglEpoch(b.t, false) : "";
            String info = waktu.isEmpty() ? b.sumber : b.sumber + ", " + waktu;
            String ref = "BR:" + out.size();
            out.add(b.judul + "\n" + info);
            refsBuf.add(ref);
            detailBuf.put(ref, b.judul + "\n\n" + info);
            if (!b.link.isEmpty()) {
                beritaLink.put(ref, b.link);
                beritaItem.put(ref, new NewsItem(b.judul, b.link, b.desc, "", b.sumber));
            }
        }
        return out;
    }

    String cariLiga(String kode) throws Exception {
        String simpan = sp.getString("id_" + kode, "");
        if (!simpan.isEmpty()) return simpan;
        JSONObject o = new JSONObject(http(TSDB + "search_all_leagues.php?c=Indonesia&s=Soccer", null));
        JSONArray a = o.optJSONArray("countries");
        if (a == null) return null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.getJSONObject(i);
            String n = x.optString("strLeague").toLowerCase(Locale.ROOT);
            if (n.contains("women") || n.contains("cup") || n.contains("piala")) continue;
            boolean cocok = n.contains("liga 1") || n.contains("super league");
            if (cocok) {
                String id = x.optString("idLeague");
                if (!id.isEmpty()) {
                    sp.edit().putString("id_" + kode, id).apply();
                    return id;
                }
            }
        }
        return null;
    }

    String cariTim() throws Exception {
        String simpan = sp.getString("id_TIM", "");
        if (!simpan.isEmpty()) return simpan;
        JSONObject o = new JSONObject(http(TSDB + "searchteams.php?t=Indonesia", null));
        JSONArray a = o.optJSONArray("teams");
        if (a == null) return null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.getJSONObject(i);
            String n = x.optString("strTeam").toLowerCase(Locale.ROOT).trim();
            boolean nasional = n.equals("indonesia") || n.equals("indonesia national team") || n.equals("timnas indonesia");
            boolean bola = "Soccer".equalsIgnoreCase(x.optString("strSport"));
            boolean putri = "Female".equalsIgnoreCase(x.optString("strGender"));
            if (nasional && bola && !putri) {
                String id = x.optString("idTeam");
                if (!id.isEmpty()) {
                    sp.edit().putString("id_TIM", id).apply();
                    return id;
                }
            }
        }
        return null;
    }

    static String[] musim() {
        Calendar c = Calendar.getInstance();
        int y = c.get(Calendar.YEAR);
        int a = c.get(Calendar.MONTH) >= 6 ? y : y - 1;
        return new String[]{a + "-" + (a + 1), (a - 1) + "-" + a};
    }

    static String waktu(JSONObject x) {
        String t = x.optString("strTimestamp", "");
        if (t.isEmpty() || "null".equals(t)) t = x.optString("dateEvent", "") + "T00:00:00";
        return t;
    }

    static String sk(JSONObject x, String f) {
        if (x.isNull(f)) return "-";
        String s = x.optString(f, "");
        return s.isEmpty() ? "-" : s;
    }

    static String barisTsdb(JSONObject x, int m) {
        String h = jelas(x.optString("strHomeTeam", "?"));
        String t = jelas(x.optString("strAwayTeam", "?"));
        if (m == 2) return tglTsdb(x, true) + ": " + h + " lawan " + t;
        return tglTsdb(x, false) + ": " + h + " " + sk(x, "intHomeScore")
                + ", " + t + " " + sk(x, "intAwayScore");
    }

    static String tglTsdb(JSONObject x, boolean jam) {
        try {
            String ts = x.optString("strTimestamp", "");
            if (!ts.isEmpty() && !"null".equals(ts) && ts.length() >= 19) {
                SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
                in.setTimeZone(TimeZone.getTimeZone("UTC"));
                SimpleDateFormat out = new SimpleDateFormat(jam ? "d MMM HH.mm" : "d MMM", new Locale("id", "ID"));
                return out.format(in.parse(ts.substring(0, 19)));
            }
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            SimpleDateFormat out = new SimpleDateFormat("d MMM", new Locale("id", "ID"));
            out.setTimeZone(TimeZone.getTimeZone("UTC"));
            return out.format(in.parse(x.optString("dateEvent")));
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- Detail pertandingan (ketuk salah satu hasil) ----------

    void detail(final String ref) {
        if (ref.startsWith("BR:")) {
            NewsItem ni = beritaItem.get(ref);
            if (ni != null) {
                android.content.Intent ia = new android.content.Intent(this, ArticleActivity.class);
                ia.putExtra("item", ni);
                startActivity(ia);
                return;
            }
            final String link = beritaLink.get(ref);
            if (link == null) {
                new AlertDialog.Builder(this).setTitle("Berita")
                        .setMessage(detailTeks.containsKey(ref) ? detailTeks.get(ref) : "Tautan berita tidak ada.")
                        .setPositiveButton("Tutup", null).show();
                return;
            }
            String teks = detailTeks.get(ref);
            android.content.Intent in = new android.content.Intent(this, BeritaActivity.class);
            in.putExtra("link", link);
            in.putExtra("judul", teks == null ? "Berita" : teks.split("\\n")[0]);
            startActivity(in);
            return;
        }
        String sudah = detailTeks.get(ref);
        if (sudah != null) {
            new AlertDialog.Builder(this).setTitle("Detail pertandingan")
                    .setMessage(sudah).setPositiveButton("Tutup", null).show();
            return;
        }
        status.setText("Memuat detail...");
        io.execute(() -> {
            String isi;
            try {
                isi = ref.startsWith("FD:") ? detailFd(ref.substring(3))
                        : ref.startsWith("ES:") ? "Detail pertandingan belum tersedia."
                        : detailTs(ref.substring(3));
            } catch (GalatHttp g) {
                isi = g.kode == 429 ? "Terlalu sering. Tunggu satu menit." : "Gagal memuat detail. Coba lagi.";
            } catch (Exception e) {
                isi = "Gagal memuat detail. Cek internet.";
            }
            final String tampil = isi;
            ui.post(() -> {
                status.setText(NAMA[liga] + ", " + namaMode(mode));
                new AlertDialog.Builder(this).setTitle("Detail pertandingan")
                        .setMessage(tampil).setPositiveButton("Tutup", null).show();
            });
        });
    }

    String detailFd(String id) throws Exception {
        JSONObject x = new JSONObject(http("https://api.football-data.org/v4/matches/" + id, FD_KEY));
        StringBuilder sb = new StringBuilder(baris(x, 1)).append("\n\n");
        JSONArray g = x.optJSONArray("goals");
        int h = 0, t = 0;
        JSONObject s = x.optJSONObject("score");
        if (s != null && s.optJSONObject("fullTime") != null) {
            h = s.getJSONObject("fullTime").optInt("home");
            t = s.getJSONObject("fullTime").optInt("away");
        }
        if (g == null || g.length() == 0) {
            if (h + t == 0) {
                sb.append("Tidak ada gol.");
                return sb.toString();
            }
            JSONObject kp = x.optJSONObject("competition");
            String kode = kp == null ? "" : kp.optString("code", "");
            if (kode.isEmpty()) kode = KODE[liga];
            alasanEspn = "";
            String espn = detailEspn(kode, nama(x.optJSONObject("homeTeam")), nama(x.optJSONObject("awayTeam")),
                    nama2(x.optJSONObject("homeTeam")), nama2(x.optJSONObject("awayTeam")),
                    h, t, epochFd(x.optString("utcDate")));
            sb.append(espn.isEmpty() ? tanpaEspn() : espn);
            return sb.toString();
        }
        for (int i = 0; i < g.length(); i++) {
            JSONObject o = g.getJSONObject(i);
            JSONObject sc = o.optJSONObject("scorer");
            JSONObject as = o.optJSONObject("assist");
            sb.append("Menit ").append(o.optInt("minute"));
            if (!o.isNull("injuryTime")) sb.append(" tambahan ").append(o.optInt("injuryTime"));
            sb.append(": ").append(sc == null ? "?" : sc.optString("name", "?"));
            sb.append(" (").append(nama(o.optJSONObject("team"))).append(")");
            String tipe = o.optString("type", "");
            if ("OWN".equals(tipe)) sb.append(", gol bunuh diri");
            else if ("PENALTY".equals(tipe)) sb.append(", penalti");
            if (as != null && !as.isNull("name")) sb.append(", assist ").append(as.optString("name"));
            sb.append("\n");
        }
        return sb.toString();
    }

    String detailTs(String id) throws Exception {
        JSONObject o = new JSONObject(http(TSDB + "lookupevent.php?id=" + id, null));
        JSONArray a = o.optJSONArray("events");
        if (a == null || a.length() == 0) return "Detail pertandingan tidak ditemukan.";
        JSONObject x = a.getJSONObject(0);
        StringBuilder sb = new StringBuilder(jelas(x.optString("strHomeTeam", "?")) + " " + sk(x, "intHomeScore")
                + ", " + jelas(x.optString("strAwayTeam", "?")) + " " + sk(x, "intAwayScore")).append("\n\n");
        String hg = bersih(x.optString("strHomeGoalDetails", ""));
        String ag = bersih(x.optString("strAwayGoalDetails", ""));
        if (hg.isEmpty() && ag.isEmpty()) {
            String hn = jelas(x.optString("strHomeTeam", "?")), an = jelas(x.optString("strAwayTeam", "?"));
            int sh = angka(sk(x, "intHomeScore")), sa = angka(sk(x, "intAwayScore"));
            if (sh == 0 && sa == 0) {
                sb.append("Tidak ada gol.");
                return sb.toString();
            }
            alasanEspn = "";
            String espn = detailEspn(KODE[liga], hn, an, hn, an, sh, sa, epochTsdb(x));
            sb.append(espn.isEmpty() ? tanpaEspn() : espn);
            return sb.toString();
        }
        if (!hg.isEmpty()) sb.append(jelas(x.optString("strHomeTeam", "Tuan rumah"))).append(":\n").append(hg).append("\n");
        if (!ag.isEmpty()) sb.append(jelas(x.optString("strAwayTeam", "Tamu"))).append(":\n").append(ag).append("\n");
        return sb.toString();
    }

    static String bersih(String t) {
        if (t == null || "null".equals(t)) return "";
        return t.replace(";", "\n").trim();
    }

    // ---------- Pencetak gol (ESPN, tanpa kunci) ----------

    // Baris hasil yang daftar golnya dilengkapi menyusul (dari ringkasan ESPN).
    static class Tunda {
        int idx;
        EvEspn e;
        String h1, a1, head, ref;
    }

    static class Gol {
        double dtk;
        String menit = "", nama = "?", tid = "";
        boolean pen, bd;
    }

    static class EvEspn {
        String id = "", idH = "", idA = "";
        long waktu;
        String namaH = "", namaA = "";
        int skorH = -1, skorA = -1;
        String tampilH = "", tampilA = "", state = "", statusNama = "", jam = "";
        final List<Gol> gol = new ArrayList<>();
    }

    // Alasan terakhir ESPN gagal (ditampilkan di detail supaya mudah dilacak).
    volatile String alasanEspn = "";

    static String espnKode(String kode) {
        for (int i = 0; i < KODE.length; i++) if (KODE[i].equals(kode)) return ESPN_LIGA[i];
        return null;
    }

    static String tglEspn(long t) {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(t));
    }

    static long epochFd(String iso) {
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            return in.parse(iso).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    static long epochTsdb(JSONObject x) {
        try {
            String ts = x.optString("strTimestamp", "");
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            if (!ts.isEmpty() && !"null".equals(ts) && ts.length() >= 19) return in.parse(ts.substring(0, 19)).getTime();
            SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            d.setTimeZone(TimeZone.getTimeZone("UTC"));
            return d.parse(x.optString("dateEvent")).getTime() + 12 * 3600000L;
        } catch (Exception e) {
            return 0;
        }
    }

    static long epochEspn(String iso) {
        String[] pola = {"yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String p : pola) {
            try {
                SimpleDateFormat in = new SimpleDateFormat(p, Locale.US);
                in.setTimeZone(TimeZone.getTimeZone("UTC"));
                return in.parse(iso).getTime();
            } catch (Exception ignore) {
            }
        }
        return 0;
    }

    static int angka(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    static String nama2(JSONObject t) {
        if (t == null) return "";
        return t.optString("name", "") + " " + t.optString("shortName", "") + " " + t.optString("tla", "");
    }

    // Kegagalan ESPN tidak boleh merusak daftar hasil: kembalikan daftar kosong.
    List<EvEspn> unduhEspn(String liga, String tanggal, boolean batas) {
        List<EvEspn> out = new ArrayList<>();
        try {
            String url = ESPN + liga + "/scoreboard?dates=" + tanggal + (batas ? "&limit=400" : "");
            JSONObject o = new JSONObject(http(url, null));
            JSONArray evs = o.optJSONArray("events");
            if (evs == null) return out;
            for (int i = 0; i < evs.length(); i++) {
                JSONObject ev = evs.getJSONObject(i);
                JSONArray comps = ev.optJSONArray("competitions");
                if (comps == null || comps.length() == 0) continue;
                JSONObject c = comps.getJSONObject(0);
                JSONArray cs = c.optJSONArray("competitors");
                if (cs == null) continue;
                EvEspn e = new EvEspn();
                e.id = ev.optString("id", "");
                e.waktu = epochEspn(ev.optString("date"));
                for (int j = 0; j < cs.length(); j++) {
                    JSONObject cp = cs.getJSONObject(j);
                    JSONObject tm = cp.optJSONObject("team");
                    String nm = tm == null ? "" : tm.optString("displayName", "") + " " + tm.optString("shortName", "")
                            + " " + tm.optString("location", "");
                    String tid = tm == null ? "" : tm.optString("id", "");
                    String tampil = tm == null ? "" : tm.optString("displayName", tm.optString("name", ""));
                    int sc = angka(cp.optString("score", ""));
                    if ("home".equals(cp.optString("homeAway"))) {
                        e.namaH = nm; e.idH = tid; e.skorH = sc; e.tampilH = tampil;
                    } else {
                        e.namaA = nm; e.idA = tid; e.skorA = sc; e.tampilA = tampil;
                    }
                }
                JSONObject stv = ev.optJSONObject("status");
                if (stv == null) stv = c.optJSONObject("status");
                if (stv != null) {
                    e.jam = stv.optString("displayClock", "").replace("'", "").trim();
                    JSONObject sty = stv.optJSONObject("type");
                    if (sty != null) {
                        e.state = sty.optString("state", "");
                        e.statusNama = sty.optString("name", "");
                    }
                }
                JSONArray det = c.optJSONArray("details");
                if (det != null) {
                    for (int j = 0; j < det.length(); j++) {
                        JSONObject d = det.getJSONObject(j);
                        if (!d.optBoolean("scoringPlay", false) || d.optBoolean("shootout", false)) continue;
                        e.gol.add(golDariJson(d));
                    }
                }
                out.add(e);
            }
        } catch (GalatHttp g) {
            alasanEspn = "ESPN membalas kode " + g.kode;
        } catch (Exception ex) {
            alasanEspn = "ESPN tidak bisa dihubungi";
        }
        return out;
    }

    // Satu gol dari data ESPN (scoreboard "details" atau summary "keyEvents").
    static Gol golDariJson(JSONObject d) {
        Gol g = new Gol();
        JSONObject tm = d.optJSONObject("team");
        g.tid = tm == null ? "" : tm.optString("id", "");
        JSONArray at = d.optJSONArray("athletesInvolved");
        if (at == null) at = d.optJSONArray("participants");
        if (at != null && at.length() > 0) {
            JSONObject p = at.optJSONObject(0);
            if (p != null) {
                String n = p.optString("displayName", "");
                if (n.isEmpty()) {
                    JSONObject ath = p.optJSONObject("athlete");
                    if (ath != null) n = ath.optString("displayName", "");
                }
                if (!n.isEmpty()) g.nama = n;
            }
        }
        JSONObject ck = d.optJSONObject("clock");
        g.menit = ck == null ? "" : ck.optString("displayValue", "").replace("'", "").trim();
        g.dtk = ck == null ? 0 : ck.optDouble("value", 0);
        JSONObject ty = d.optJSONObject("type");
        String tt = ty == null ? "" : ty.optString("text", "").toLowerCase(Locale.ROOT);
        g.bd = d.optBoolean("ownGoal", false) || tt.contains("own goal");
        g.pen = !g.bd && (d.optBoolean("penaltyKick", false) || tt.contains("penalty"));
        return g;
    }

    List<EvEspn> ambilEspn(String kode, long dari, long sampai) {
        List<EvEspn> out = new ArrayList<>();
        String liga = espnKode(kode);
        if (liga == null) return out;
        alasanEspn = "";
        long a = dari - 86400000L, b = sampai + 86400000L;
        out = unduhEspn(liga, tglEspn(a) + "-" + tglEspn(b), true);
        if (!out.isEmpty()) return out;
        // Cadangan: tarik per hari kalau permintaan rentang tanggal tidak membuahkan hasil.
        // Paralel dan sampai 40 hari, supaya rentang panjang (Liga Champions: satu pekan main, dua pekan libur)
        // tidak terpotong dan pertandingan terbaru tidak kehilangan nama pencetak gol.
        java.util.LinkedHashSet<String> hari = new java.util.LinkedHashSet<>();
        int n = 0;
        for (long t = a; t <= b && n < 40; t += 86400000L, n++) hari.add(tglEspn(t));
        return gabungEspn(out, unduhHariParalel(liga, hari));
    }

    static List<EvEspn> gabungEspn(List<EvEspn> dasar, List<EvEspn> tambahan) {
        List<EvEspn> r = new ArrayList<>(dasar);
        Set<String> ada = new HashSet<>();
        for (EvEspn e : r) if (!e.id.isEmpty()) ada.add(e.id);
        for (EvEspn e : tambahan) if (e.id.isEmpty() || ada.add(e.id)) r.add(e);
        return r;
    }

    // Ambil scoreboard ESPN untuk sekumpulan hari (format yyyyMMdd) secara paralel.
    List<EvEspn> unduhHariParalel(final String liga, java.util.Collection<String> hari) {
        List<EvEspn> out = new ArrayList<>();
        if (hari.isEmpty()) return out;
        ExecutorService kolam = Executors.newFixedThreadPool(6);
        try {
            List<java.util.concurrent.Callable<List<EvEspn>>> tugas = new ArrayList<>();
            for (final String h : hari) tugas.add(() -> unduhEspn(liga, h, false));
            for (java.util.concurrent.Future<List<EvEspn>> f : kolam.invokeAll(tugas)) {
                try {
                    out = gabungEspn(out, f.get());
                } catch (Exception ignore) {
                }
            }
        } catch (Exception ignore) {
        } finally {
            kolam.shutdown();
        }
        return out;
    }

    // Pertandingan FD yang belum ketemu di hasil rentang ESPN dicari lagi per harinya.
    List<EvEspn> lengkapiHari(String kode, List<EvEspn> esp, List<JSONObject> terpilih) {
        String liga = espnKode(kode);
        if (liga == null) return esp;
        java.util.LinkedHashSet<String> hari = new java.util.LinkedHashSet<>();
        for (JSONObject mx : terpilih) {
            JSONObject sc = mx.optJSONObject("score");
            int sh = angka(skor(sc, "home")), sa = angka(skor(sc, "away"));
            long w = epochFd(mx.optString("utcDate"));
            if (w <= 0 || sh + sa <= 0) continue;
            EvEspn e = cocok(esp, nama(mx.optJSONObject("homeTeam")), nama(mx.optJSONObject("awayTeam")),
                    nama2(mx.optJSONObject("homeTeam")), nama2(mx.optJSONObject("awayTeam")), sh, sa, w);
            if (e == null) {
                hari.add(tglEspn(w));
                if (hari.size() >= 12) break;
            }
        }
        if (hari.isEmpty()) return esp;
        return gabungEspn(esp, unduhHariParalel(liga, hari));
    }

    // Kalau scoreboard tidak memuat daftar gol, ambil dari ringkasan pertandingan ESPN.
    void isiRingkasan(String kode, EvEspn e) {
        try {
            String liga = espnKode(kode);
            if (liga == null || e.id.isEmpty()) return;
            JSONObject o = new JSONObject(http(ESPN + liga + "/summary?event=" + e.id, null));
            JSONArray ke = o.optJSONArray("keyEvents");
            if (ke == null) return;
            for (int i = 0; i < ke.length(); i++) {
                JSONObject k = ke.getJSONObject(i);
                JSONObject ty = k.optJSONObject("type");
                String tt = ty == null ? "" : (ty.optString("text", "") + " " + ty.optString("type", "")).toLowerCase(Locale.ROOT);
                boolean skor;
                if (k.has("scoringPlay")) skor = k.optBoolean("scoringPlay", false);
                else skor = (tt.contains("goal") && !tt.contains("disallow") && !tt.contains("no goal"))
                        || tt.contains("penalty - scored") || tt.contains("penalty---scored");
                if (!skor || tt.contains("shootout") || k.optBoolean("shootout", false)) continue;
                e.gol.add(golDariJson(k));
            }
        } catch (GalatHttp g) {
            alasanEspn = "ringkasan ESPN membalas kode " + g.kode;
        } catch (Exception ex) {
            alasanEspn = "ringkasan ESPN tidak bisa dihubungi";
        }
    }

    static List<Gol> urut(List<Gol> a) {
        List<Gol> r = new ArrayList<>(a);
        Collections.sort(r, (p, q) -> Double.compare(p.dtk, q.dtk));
        return r;
    }

    static final Set<String> BUANG = new HashSet<>(java.util.Arrays.asList(
            "fc", "afc", "cf", "sc", "the", "de", "club", "and", "ac", "as", "ssc", "us"));

    static Set<String> token(String s) {
        Set<String> r = new HashSet<>();
        String n = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        String t = n.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
        if (t.isEmpty()) return r;
        for (String w : t.split(" ")) {
            if (w.length() >= 3 && !BUANG.contains(w)) r.add(w);
        }
        return r;
    }

    static int mirip(Set<String> x, Set<String> y) {
        int n = 0;
        for (String p : x) {
            for (String q : y) {
                int k = Math.min(4, Math.min(p.length(), q.length()));
                if (p.equals(q) || p.regionMatches(0, q, 0, k)) {
                    n++;
                    break;
                }
            }
        }
        return n;
    }

    // Cari pertandingan yang sama di ESPN (waktu, nama tim, dan skor sebagai penguat).
    EvEspn cocok(List<EvEspn> esp, String h1, String a1, String h2, String a2, int sh, int sa, long waktu) {
        if (esp.isEmpty() || waktu <= 0) return null;
        Set<String> th = token(h1 + " " + h2), ta = token(a1 + " " + a2);
        EvEspn terbaik = null;
        int nilai = 0;
        for (EvEspn e : esp) {
            if (Math.abs(e.waktu - waktu) > 30 * 3600000L) continue;
            int mh = mirip(th, token(e.namaH)), ma = mirip(ta, token(e.namaA));
            boolean sama = e.skorH == sh && e.skorA == sa;
            // Nama klub di dua sumber sering beda (Liga Champions): satu sisi yang cocok cukup kalau skornya sama.
            if ((mh == 0 || ma == 0) && !(sama && (mh > 0 || ma > 0))) continue;
            int n = mh + ma + (sama ? 10 : 0);
            if (n > nilai) {
                nilai = n;
                terbaik = e;
            }
        }
        if (terbaik != null) return terbaik;
        int jumlahSkorSama = 0;
        EvEspn satu = null;
        for (EvEspn e : esp) {
            if (Math.abs(e.waktu - waktu) > 30 * 3600000L) continue;
            if (e.skorH != sh || e.skorA != sa) continue;
            jumlahSkorSama++;
            satu = e;
        }
        if (jumlahSkorSama == 1 && satu != null
                && (mirip(th, token(satu.namaH)) > 0 || mirip(ta, token(satu.namaA)) > 0)) return satu;
        return null;
    }

    // Teks gol untuk baris daftar. Kalau ESPN cocok tapi belum memuat gol, dijadwalkan diisi menyusul.
    String isiBaris(List<EvEspn> esp, String ref, String head, String h1, String a1, String h2, String a2,
                    int sh, int sa, long waktu, int idx) {
        if (esp.isEmpty() || waktu <= 0 || sh < 0 || sa < 0 || sh + sa == 0) return "";
        EvEspn e = cocok(esp, h1, a1, h2, a2, sh, sa, waktu);
        if (e == null) return "";
        if (e.gol.isEmpty()) {
            Tunda t = new Tunda();
            t.idx = idx; t.e = e; t.h1 = h1; t.a1 = a1; t.head = head; t.ref = ref;
            tundaBuf.add(t);
            return "";
        }
        String gol = ringkasGol(e, h1, a1);
        if (!gol.isEmpty()) detailBuf.put(ref, head + "\n\n" + detailGol(e, h1, a1));
        return gol;
    }

    static String ringkasGol(EvEspn e, String h1, String a1) {
        StringBuilder gh = new StringBuilder(), ga = new StringBuilder();
        for (Gol g : urut(e.gol)) {
            String t = g.nama + (g.menit.isEmpty() ? "" : " menit " + g.menit);
            if (g.bd) t += " (gol bunuh diri)";
            else if (g.pen) t += " (penalti)";
            StringBuilder tujuan = !g.tid.isEmpty() && g.tid.equals(e.idA) ? ga : gh;
            if (tujuan.length() > 0) tujuan.append("; ");
            tujuan.append(t);
        }
        StringBuilder sb = new StringBuilder();
        if (gh.length() > 0) sb.append(h1).append(": ").append(gh);
        if (ga.length() > 0) {
            if (sb.length() > 0) sb.append("\n");
            sb.append(a1).append(": ").append(ga);
        }
        return sb.toString();
    }

    static String detailGol(EvEspn e, String h1, String a1) {
        StringBuilder sb = new StringBuilder();
        for (Gol g : urut(e.gol)) {
            boolean tamu = !g.tid.isEmpty() && g.tid.equals(e.idA);
            sb.append("Menit ").append(g.menit.isEmpty() ? "?" : g.menit).append(": ").append(g.nama)
                    .append(" (").append(tamu ? a1 : h1).append(")");
            if (g.bd) sb.append(", gol bunuh diri");
            else if (g.pen) sb.append(", penalti");
            sb.append("\n");
        }
        return sb.toString().trim();
    }

    // Daftar gol lengkap untuk dialog detail: menit, nama, tim, penalti atau bukan.
    String detailEspn(String kode, String h1, String a1, String h2, String a2, int sh, int sa, long waktu) {
        try {
            if (espnKode(kode) == null) {
                alasanEspn = "liga ini tidak ada di ESPN";
                return "";
            }
            List<EvEspn> esp = ambilEspn(kode, waktu, waktu);
            EvEspn e = cocok(esp, h1, a1, h2, a2, sh, sa, waktu);
            if (e == null) {
                if (alasanEspn.isEmpty()) alasanEspn = "pertandingan tidak ditemukan di ESPN (" + esp.size() + " pertandingan diperiksa)";
                return "";
            }
            if (e.gol.isEmpty()) isiRingkasan(kode, e);
            if (e.gol.isEmpty()) {
                if (alasanEspn.isEmpty()) alasanEspn = "ESPN belum mencantumkan pencetak gol";
                return "";
            }
            return detailGol(e, h1, a1);
        } catch (Exception ex) {
            alasanEspn = "galat saat membaca data ESPN";
            return "";
        }
    }

    String tanpaEspn() {
        return "Nama pencetak gol belum tersedia untuk pertandingan ini."
                + (alasanEspn.isEmpty() ? "" : "\n(Sumber ESPN: " + alasanEspn + ")");
    }

    // ---------- HTTP ----------

    // ---------- Berita terbaru (Google News RSS, bahasa Indonesia) ----------

    List<String> ambilBerita() throws Exception {
        String q = KUERI_BERITA[liga] + " when:7d";
        String u = "https://news.google.com/rss/search?q=" + java.net.URLEncoder.encode(q, "UTF-8")
                + "&hl=id&gl=ID&ceid=ID:id";
        String xml = httpXml(u);
        beritaLink.clear();
        beritaItem.clear();
        List<String> out = new ArrayList<>();
        java.util.regex.Matcher mi = java.util.regex.Pattern.compile("<item>(.*?)</item>", java.util.regex.Pattern.DOTALL).matcher(xml);
        long sekarang = System.currentTimeMillis();
        SimpleDateFormat f = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
        while (mi.find() && out.size() < 25) {
            String it = mi.group(1);
            String judul = tag(it, "title");
            String link = tag(it, "link");
            String sumber = tag(it, "source");
            String tgl = tag(it, "pubDate");
            if (judul.isEmpty()) continue;
            if (!sumber.isEmpty() && judul.endsWith(" - " + sumber)) {
                judul = judul.substring(0, judul.length() - sumber.length() - 3);
            }
            String waktu = "";
            long t = 0;
            try { t = f.parse(tgl).getTime(); } catch (Exception e) { }
            if (t > 0) waktu = lalu(sekarang - t);
            String info = sumber.isEmpty() ? waktu : (waktu.isEmpty() ? sumber : sumber + ", " + waktu);
            String ref = "BR:" + out.size();
            out.add(info.isEmpty() ? judul : judul + "\n" + info);
            refsBuf.add(ref);
            detailBuf.put(ref, judul + (info.isEmpty() ? "" : "\n\n" + info));
            if (!link.isEmpty()) beritaLink.put(ref, link);
        }
        return out;
    }

    static String lalu(long ms) {
        long mnt = ms / 60000;
        if (mnt < 1) return "baru saja";
        if (mnt < 60) return mnt + " menit lalu";
        long jam = mnt / 60;
        if (jam < 24) return jam + " jam lalu";
        return (jam / 24) + " hari lalu";
    }

    static String tag(String blok, String nama) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("<" + nama + "[^>]*>(.*?)</" + nama + ">", java.util.regex.Pattern.DOTALL).matcher(blok);
        if (!m.find()) return "";
        String v = m.group(1).trim();
        if (v.startsWith("<![CDATA[") && v.endsWith("]]>")) v = v.substring(9, v.length() - 3);
        return v.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&apos;", "'").replace("&amp;", "&").trim();
    }

    String httpXml(String u) throws Exception {
        synchronized (CACHE) {
            Object[] t = CACHE.get(u);
            if (t != null && System.currentTimeMillis() - (Long) t[0] < CACHE_MS) return (String) t[1];
        }
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        String hasil;
        try {
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) SkorBolaBaru");
            c.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml");
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            int code = c.getResponseCode();
            if (code != 200) throw new GalatHttp(code, null);
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            hasil = sb.toString();
        } finally {
            c.disconnect();
        }
        synchronized (CACHE) { CACHE.put(u, new Object[]{System.currentTimeMillis(), hasil}); }
        return hasil;
    }

    static final java.util.HashMap<String, Object[]> CACHE = new java.util.HashMap<>();
    static final long CACHE_MS = 90000;

    // Data pertandingan yang sudah lama selesai tidak berubah, jadi disimpan lebih lama supaya buka ulang terasa cepat.
    // Sedang main, hari ini, dan kemarin tetap 90 detik. Tombol Segarkan selalu mengosongkan simpanan.
    static long umurCache(String u) {
        int i = u.indexOf("/scoreboard?dates=");
        if (i >= 0) {
            String d = u.substring(i + 18);
            boolean sehari = d.length() == 8 || (d.length() > 8 && d.charAt(8) == '&');
            if (sehari && d.substring(0, 8).matches("\\d{8}")
                    && d.substring(0, 8).compareTo(tglEspn(System.currentTimeMillis() - 2 * 86400000L)) < 0) return 3600000L;
            return CACHE_MS;
        }
        if (u.contains("/summary?event=")) return 600000L;
        return CACHE_MS;
    }

    String http(String u, String kunci) throws Exception {
        synchronized (CACHE) {
            Object[] t = CACHE.get(u);
            if (t != null && System.currentTimeMillis() - (Long) t[0] < umurCache(u)) return (String) t[1];
        }
        String hasil = httpLangsung(u, kunci);
        synchronized (CACHE) { CACHE.put(u, new Object[]{System.currentTimeMillis(), hasil}); }
        return hasil;
    }

    String httpLangsung(String u, String kunci) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) SkorBolaBaru");
            c.setRequestProperty("Accept", "application/json");
            if (kunci != null && !kunci.isEmpty()) c.setRequestProperty("X-Auth-Token", kunci);
            c.setConnectTimeout(8000);
            c.setReadTimeout(12000);
            int code = c.getResponseCode();
            if (code != 200) throw new GalatHttp(code, null);
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }
}
